import express from "express";

import {
    createBooking,
    getAllBookings,
    getBookingById,
    getBookingsByCustomer,
    getActiveBookings,
    updateBooking,
    deleteBooking,
    addBookingPayment,
    checkoutRooms,
    addFoodService,
    addRoomService,
    markFoodServicesPaid,
    markRoomServicesPaid,
} from "../controllers/bookingController.js";

import {
    authVerify,
    permissionVerify,
} from "../middleware/userVerify.js";

const router = express.Router();

// ===============================
// BOOKING
// ===============================

router.post(
    "/",
    authVerify,
    permissionVerify("rooms-booking"),
    createBooking
);

router.get(
    "/",
    authVerify,
    permissionVerify("rooms-booking"),
    getAllBookings
);

router.get(
    "/active",
    authVerify,
    permissionVerify("rooms-booking"),
    getActiveBookings
);

router.get(
    "/customer/:customerId",
    authVerify,
    permissionVerify("rooms-booking"),
    getBookingsByCustomer
);

router.get(
    "/:id",
    authVerify,
    permissionVerify("rooms-booking"),
    getBookingById
);

router.put(
    "/:id",
    authVerify,
    permissionVerify("rooms-booking"),
    updateBooking
);

router.delete(
    "/:id",
    authVerify,
    permissionVerify("rooms-booking"),
    deleteBooking
);

// ===============================
// PAYMENTS
// ===============================

router.post(
    "/:id/payment",
    authVerify,
    permissionVerify("rooms-booking"),
    addBookingPayment
);

// ===============================
// CHECKOUT
// ===============================

router.post(
    "/:id/checkout",
    authVerify,
    permissionVerify("rooms-booking"),
    checkoutRooms
);

// ===============================
// FOOD SERVICES
// ===============================

router.post(
    "/:id/rooms/:roomId/food",
    authVerify,
    permissionVerify("food-management"),
    addFoodService
);

router.patch(
    "/:id/rooms/:roomId/food/paid",
    authVerify,
    permissionVerify("food-management"),
    markFoodServicesPaid
);

// ===============================
// ROOM SERVICES
// ===============================

router.post(
    "/:id/rooms/:roomId/room-service",
    authVerify,
    permissionVerify("food-management"),
    addRoomService
);

router.patch(
    "/:id/rooms/:roomId/room-service/paid",
    authVerify,
    permissionVerify("food-management"),
    markRoomServicesPaid
);

export default router;
