import express from "express";
import {
    createInvoice,
    getAllInvoices,
    getInvoiceById,
    deleteInvoice,
} from "../controllers/invoiceController.js";

import {
    authVerify,
    permissionVerify,
} from "../middleware/userVerify.js";

const router = express.Router();

router.post(
    "/",
    authVerify,
    permissionVerify("reports"),
    createInvoice
);

router.get(
    "/",
    authVerify,
    permissionVerify("reports"),
    getAllInvoices
);

router.get(
    "/:id",
    authVerify,
    permissionVerify("reports"),
    getInvoiceById
);

router.delete(
    "/:id",
    authVerify,
    permissionVerify("reports"),
    deleteInvoice
);

export default router;
