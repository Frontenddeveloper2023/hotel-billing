import express from "express";

import {
    createFoodService,
    getAllFoodServices,
    getFoodServicesByBooking,
    updateFoodService,
    deleteFoodService,
    markFoodServicesPaid,
} from "../controllers/foodServiceController.js";

import {
    authVerify,
    permissionVerify,
} from "../middleware/userVerify.js";

const router = express.Router();

// Get all embedded food services
router.get(
    "/",
    authVerify,
    permissionVerify("food-management"),
    getAllFoodServices
);

// Get food services for one booking
router.get(
    "/booking/:bookingId",
    authVerify,
    permissionVerify("food-management"),
    getFoodServicesByBooking
);

// Add food
router.post(
    "/bookings/:bookingId/rooms/:roomId",
    authVerify,
    permissionVerify("food-management"),
    createFoodService
);

// Update food
router.put(
    "/bookings/:bookingId/rooms/:roomId/:foodServiceId",
    authVerify,
    permissionVerify("food-management"),
    updateFoodService
);

// Delete food
router.delete(
    "/bookings/:bookingId/rooms/:roomId/:foodServiceId",
    authVerify,
    permissionVerify("food-management"),
    deleteFoodService
);

// Mark food paid
router.patch(
    "/bookings/:bookingId/rooms/:roomId/paid",
    authVerify,
    permissionVerify("food-management"),
    markFoodServicesPaid
);

export default router;
