import express from "express";
import {
    createService,
    getAllServices,
    getService,
    updateService,
    deleteService,
} from "../controllers/roomServiceListControleController.js";

import {
    authVerify,
    permissionVerify,
} from "../middleware/userVerify.js";

const router = express.Router();

router.post(
    "/create-service",
    authVerify,
    permissionVerify("food-management"),
    createService
);

router.get(
    "/get-all-services",
    authVerify,
    permissionVerify("food-management"),
    getAllServices
);

router.get(
    "/get-service/:id",
    authVerify,
    permissionVerify("food-management"),
    getService
);

router.put(
    "/update-service/:id",
    authVerify,
    permissionVerify("food-management"),
    updateService
);

router.delete(
    "/delete-service/:id",
    authVerify,
    permissionVerify("food-management"),
    deleteService
);

export default router;
