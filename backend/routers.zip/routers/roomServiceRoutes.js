import express from "express";

import {
    addRoomService,
    getAllServices,
    getServicesByBooking,
    updateRoomService,
    deleteRoomService,
    markRoomServicesPaid,
} from "../controllers/roomServiceController.js";

import {
    authVerify,
    permissionVerify,
} from "../middleware/userVerify.js";

const router = express.Router();

// Get all embedded room services
router.get(
    "/",
    authVerify,
    permissionVerify("food-management"),
    getAllServices
);

// Get services for one booking
router.get(
    "/booking/:bookingId",
    authVerify,
    permissionVerify("food-management"),
    getServicesByBooking
);

// Add room service
router.post(
    "/bookings/:bookingId/rooms/:roomId",
    authVerify,
    permissionVerify("food-management"),
    addRoomService
);

// Update room service
router.put(
    "/bookings/:bookingId/rooms/:roomId/:serviceId",
    authVerify,
    permissionVerify("food-management"),
    updateRoomService
);

// Delete room service
router.delete(
    "/bookings/:bookingId/rooms/:roomId/:serviceId",
    authVerify,
    permissionVerify("food-management"),
    deleteRoomService
);

// Mark room services paid
router.patch(
    "/bookings/:bookingId/rooms/:roomId/paid",
    authVerify,
    permissionVerify("food-management"),
    markRoomServicesPaid
);

export default router;
