import express from "express";
import {
    createFood,
    getAllFood,
    getFoodById,
    updateFood,
    deleteFood,
} from "../controllers/foodController.js";
import { uploadFoodImage } from "../middleware/uploadMiddleware.js";
import {
    authVerify,
    permissionVerify,
} from "../middleware/userVerify.js";

const router = express.Router();

router.post(
    "/food-img-upload",
    authVerify,
    permissionVerify("food-management"),
    uploadFoodImage,
    createFood
);

router.get(
    "/get-foods",
    authVerify,
    permissionVerify("food-management"),
    getAllFood
);

router.get(
    "/get-food/:id",
    authVerify,
    permissionVerify("food-management"),
    getFoodById
);

router.put(
    "/update-food/:id",
    authVerify,
    permissionVerify("food-management"),
    uploadFoodImage,
    updateFood
);

router.delete(
    "/delete-food/:id",
    authVerify,
    permissionVerify("food-management"),
    deleteFood
);

export default router;
