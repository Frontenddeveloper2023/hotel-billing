import express from "express";
import {
    createUser,
    getAllUsers,
    updateUser,
    deleteUser,
} from "../controllers/userContoller.js";

import {
    authVerify,
    permissionVerify,
} from "../middleware/userVerify.js";

const router = express.Router();

router.get(
    "/list-users",
    authVerify,
    permissionVerify("users"),
    getAllUsers
);

router.post(
    "/add-user",
    authVerify,
    permissionVerify("users"),
    createUser
);

router.put(
    "/update-user/:id",
    authVerify,
    permissionVerify("users"),
    updateUser
);

router.delete(
    "/delete-user/:id",
    authVerify,
    permissionVerify("users"),
    deleteUser
);

export default router;
