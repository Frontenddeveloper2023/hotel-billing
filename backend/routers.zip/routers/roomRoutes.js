import express from "express";

import {
    addRoom,
    getAllRooms,
    getRoom,
    updateRoom,
    deleteRoom,
} from "../controllers/roomController.js";

import {
    authVerify,
    permissionVerify,
} from "../middleware/userVerify.js";

const router = express.Router();

// Add new room
router.post(
    "/add",
    authVerify,
    permissionVerify("rooms-booking"),
    addRoom
);

// Get all rooms
router.get(
    "/all",
    authVerify,
    permissionVerify("rooms-booking"),
    getAllRooms
);

// Get single room
router.get(
    "/:id",
    authVerify,
    permissionVerify("rooms-booking"),
    getRoom
);

// Update room
router.put(
    "/:id",
    authVerify,
    permissionVerify("rooms-booking"),
    updateRoom
);

// Delete room
router.delete(
    "/:id",
    authVerify,
    permissionVerify("rooms-booking"),
    deleteRoom
);

export default router;
