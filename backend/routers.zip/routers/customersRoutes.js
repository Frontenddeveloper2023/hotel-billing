import express from "express";
import {
    createCustomer,
    getAllCustomers,
    getCustomerById,
    updateCustomer,
    deleteCustomer,
} from "../controllers/customersController.js";

import {
    authVerify,
    permissionVerify,
} from "../middleware/userVerify.js";

const router = express.Router();

router.post(
    "/create-customer",
    authVerify,
    permissionVerify("customer"),
    createCustomer
);

router.get(
    "/get-customer",
    authVerify,
    permissionVerify("customer"),
    getAllCustomers
);

router.get(
    "/get-customer/:id",
    authVerify,
    permissionVerify("customer"),
    getCustomerById
);

router.put(
    "/update-customer/:id",
    authVerify,
    permissionVerify("customer"),
    updateCustomer
);

router.delete(
    "/delete-customer/:id",
    authVerify,
    permissionVerify("customer"),
    deleteCustomer
);

export default router;
