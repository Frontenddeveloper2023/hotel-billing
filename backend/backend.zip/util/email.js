import nodemailer from "nodemailer";

import { log } from "./logger.js";

const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT),
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
    }
});

const sendOTP = async (to, otp) => {
    try {
        await transporter.sendMail({
            from: `"SS Residency" <${process.env.SMTP_USER}>`,
            to,
            subject: 'Your SS Residency Verification Code',

            text: `Your SS Residency verification code is ${otp}. This code is valid for 10 minutes.`,

            html: `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SS Residency - OTP Verification</title>
</head>

<body style="
    margin: 0;
    padding: 0;
    background-color: #f3f9fa;
    font-family: Arial, Helvetica, sans-serif;
    color: #111827;
">

<table width="100%" cellpadding="0" cellspacing="0" border="0"
    style="background-color: #f3f9fa; padding: 40px 15px;">

    <tr>
        <td align="center">

            <!-- Main Container -->
            <table width="100%" cellpadding="0" cellspacing="0" border="0"
                style="
                    max-width: 520px;
                    background-color: #ffffff;
                    border: 1px solid #d5e1e4;
                    border-radius: 12px;
                    overflow: hidden;
                ">

                <!-- Header -->
                <tr>
                    <td style="
                        padding: 30px 35px 20px;
                        text-align: left;
                    ">

                        <div style="
                            font-size: 24px;
                            font-weight: 700;
                            color: #065b62;
                            margin-bottom: 22px;
                        ">
                            SS Residency
                        </div>

                        <div style="
                            font-size: 24px;
                            font-weight: 700;
                            color: #111111;
                            margin-bottom: 10px;
                        ">
                            Verification Code
                        </div>

                        <div style="
                            font-size: 14px;
                            line-height: 22px;
                            color: #4b5563;
                        ">
                            Use the verification code below to sign in
                            to your SS Residency account.
                        </div>

                    </td>
                </tr>

                <!-- OTP Section -->
                <tr>
                    <td style="padding: 10px 35px 25px;">

                        <div style="
                            background-color: #f3f9fa;
                            border: 1px solid #d7e6e8;
                            border-radius: 8px;
                            padding: 25px 20px;
                            text-align: center;
                        ">

                            <div style="
                                font-size: 12px;
                                font-weight: 600;
                                color: #52666a;
                                text-transform: uppercase;
                                letter-spacing: 1px;
                                margin-bottom: 12px;
                            ">
                                Your OTP
                            </div>

                            <div style="
                                font-size: 34px;
                                font-weight: 700;
                                letter-spacing: 8px;
                                color: #065b62;
                            ">
                                ${otp}
                            </div>

                        </div>

                    </td>
                </tr>

                <!-- Information -->
                <tr>
                    <td style="padding: 0 35px 25px;">

                        <p style="
                            margin: 0 0 10px;
                            font-size: 14px;
                            line-height: 21px;
                            color: #4b5563;
                        ">
                            This verification code is valid for
                            <strong style="color: #065b62;">5 minutes</strong>.
                        </p>

                        <p style="
                            margin: 0;
                            font-size: 13px;
                            line-height: 20px;
                            color: #6b7280;
                        ">
                            If you did not request this code, you can safely
                            ignore this email.
                        </p>

                    </td>
                </tr>

                <!-- Divider -->
                <tr>
                    <td style="padding: 0 35px;">
                        <div style="
                            height: 1px;
                            background-color: #e5eef0;
                        "></div>
                    </td>
                </tr>

                <!-- Footer -->
                <tr>
                    <td style="
                        padding: 22px 35px 28px;
                        text-align: center;
                    ">

                        <div style="
                            font-size: 12px;
                            color: #52666a;
                            margin-bottom: 8px;
                        ">
                            SS Residency Hotel Management • Secured Access
                        </div>

                        <div style="
                            font-size: 12px;
                            color: #718096;
                        ">
                            🔒 Your information is secure and encrypted
                        </div>

                    </td>
                </tr>

            </table>

            <!-- Bottom Text -->
            <div style="
                max-width: 520px;
                padding-top: 18px;
                text-align: center;
                font-size: 11px;
                line-height: 18px;
                color: #8a9a9d;
            ">
                This is an automated email. Please do not reply to this message.
            </div>

        </td>
    </tr>

</table>

</body>
</html>
            `
        });

        log(`OTP sent to ${to}`);

    } catch (error) {
        console.error('Error sending OTP:', error);
        log(`Error sending OTP to ${to}: ${error.message}`);
        throw error;
    }
};


export { sendOTP };