import jwt from "jsonwebtoken";
import { log } from "../util/logger.js";


// =====================================================
// AUTH VERIFY
// =====================================================

const authVerify = (req, res, next) => {
    try {

        const token = req.cookies.hotelbilling;


        // =================================================
        // TOKEN NOT FOUND
        // =================================================

        if (!token) {

            log(
                "[Auth Verify] Authentication token not found"
            );

            return res.status(401).json({
                message: "Unauthorized",
            });
        }


        // =================================================
        // VERIFY TOKEN
        // =================================================

        try {

            const decoded = jwt.verify(
                token,
                process.env.JWT_SECRET
            );

            req.user = decoded;

            next();

        } catch (error) {

            // =============================================
            // TOKEN EXPIRED
            // =============================================

            if (error instanceof jwt.TokenExpiredError) {

                log(
                    `[Auth Verify] Token expired: ${error.message}`
                );

                return res.status(401).json({
                    message: "Session expired. Please login again.",
                });
            }


            // =============================================
            // INVALID TOKEN
            // =============================================

            if (error instanceof jwt.JsonWebTokenError) {

                log(
                    `[Auth Verify] Invalid token: ${error.message}`
                );

                return res.status(401).json({
                    message: "Invalid authentication token.",
                });
            }


            // =============================================
            // TOKEN NOT ACTIVE YET
            // =============================================

            if (error instanceof jwt.NotBeforeError) {

                log(
                    `[Auth Verify] Token is not active: ${error.message}`
                );

                return res.status(401).json({
                    message: "Authentication token is not active.",
                });
            }


            // =============================================
            // UNKNOWN JWT ERROR
            // =============================================

            log(
                `[Auth Verify] JWT verification error: ${error.message}`
            );

            return res.status(500).json({
                message: "Internal server error",
            });
        }

    } catch (error) {

        console.error(
            "[Auth Verify] Unexpected error:",
            error
        );

        log(
            `[Auth Verify] Unexpected error: ${error.message}`
        );

        return res.status(500).json({
            message: "Internal server error",
        });
    }
};


// =====================================================
// ADMIN VERIFY
// =====================================================

const adminVerify = (req, res, next) => {
    try {

        const token = req.cookies.hotelbilling;


        // =================================================
        // TOKEN NOT FOUND
        // =================================================

        if (!token) {

            log(
                "[Admin Verify] Authentication token not found"
            );

            return res.status(401).json({
                message: "Unauthorized",
            });
        }


        // =================================================
        // VERIFY TOKEN
        // =================================================

        try {

            const decoded = jwt.verify(
                token,
                process.env.JWT_SECRET
            );


            // =============================================
            // ADMIN ROLE CHECK
            // =============================================

            if (decoded.role !== "admin") {

                log(
                    `[Admin Verify] Forbidden access. User ID: ${
                        decoded.id || decoded.userId || "unknown"
                    }, Role: ${
                        decoded.role || "unknown"
                    }`
                );

                return res.status(403).json({
                    message: "Forbidden",
                });
            }


            req.user = decoded;

            next();

        } catch (error) {

            // =============================================
            // TOKEN EXPIRED
            // =============================================

            if (error instanceof jwt.TokenExpiredError) {

                log(
                    `[Admin Verify] Token expired: ${error.message}`
                );

                return res.status(401).json({
                    message: "Session expired. Please login again.",
                });
            }


            // =============================================
            // INVALID TOKEN
            // =============================================

            if (error instanceof jwt.JsonWebTokenError) {

                log(
                    `[Admin Verify] Invalid token: ${error.message}`
                );

                return res.status(401).json({
                    message: "Invalid authentication token.",
                });
            }


            // =============================================
            // TOKEN NOT ACTIVE YET
            // =============================================

            if (error instanceof jwt.NotBeforeError) {

                log(
                    `[Admin Verify] Token is not active: ${error.message}`
                );

                return res.status(401).json({
                    message: "Authentication token is not active.",
                });
            }


            // =============================================
            // UNKNOWN JWT ERROR
            // =============================================

            log(
                `[Admin Verify] JWT verification error: ${error.message}`
            );

            return res.status(500).json({
                message: "Internal server error",
            });
        }

    } catch (error) {

        console.error(
            "[Admin Verify] Unexpected error:",
            error
        );

        log(
            `[Admin Verify] Unexpected error: ${error.message}`
        );

        return res.status(500).json({
            message: "Internal server error",
        });
    }
};


// =====================================================
// EXPORT
// =====================================================

export {
    authVerify,
    adminVerify,
};