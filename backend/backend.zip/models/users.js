import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
        },

        role: {
            type: String,
            required: true,
            enum: ["admin", "receptionist"],
        },

        email: {
            type: String,
            required: true,
            unique: true,
        },

        status: {
            type: String,
            enum: ["active", "inactive"],
            default: "active",
        },

        otp: {
            type: Number,
            default: null,
        },

        otpExpiresAt: {
            type: Date,
            default: null,
        },

        permission: {
            type: Object,
            default: {},
        },
    },
    {
        timestamps: true, // adds createdAt / updatedAt — needed since getAllUsers sorts by createdAt
    }
);

export default mongoose.model("Users", userSchema);