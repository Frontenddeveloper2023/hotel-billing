import mongoose from "mongoose";

const foodServiceSchema = new mongoose.Schema(
  {
    // Customer who ordered the food
    customerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Customer",
      required: [true, "Customer ID is required."],
    },

    roomNumber: {
      type: String,
      required: [true, "Room number is required."],
      trim: true,
      index: true,
    },

    // Food master record
    foodId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Food",
      required: [true, "Food ID is required."],
    },

    foodName: {
      type: String,
      required: [true, "Food name is required."],
      trim: true,
    },

    foodPrice: {
      type: Number,
      required: [true, "Food price is required."],
      min: [0, "Price cannot be negative."],
    },

    quantity: {
      type: Number,
      required: [true, "Quantity is required."],
      min: [1, "Quantity must be at least 1."],
      default: 1,
    },

    totalPrice: {
      type: Number,
      required: [true, "Total price is required."],
      min: [0, "Total price cannot be negative."],
    },

    // Pending → Paid
    paymentStatus: {
      type: String,
      enum: ["Pending", "Paid"],
      default: "Pending",
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.model("FoodService", foodServiceSchema);