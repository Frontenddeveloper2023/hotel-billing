import mongoose from "mongoose";

const roomSchema = new mongoose.Schema(
    {
        roomNumber: {
            type: String,
            trim: true,
        },

        roomType: {
            type: String,
            trim: true,
        },

        bedType: {
            type: String,
            trim: true,
        },

        pricePerNight: {
            type: Number,
        },

        status: {
            type: String,
            default: "available",
            trim: true,
        },
    },
    {
        timestamps: true,
    }
);

export default mongoose.model(
    "Room",
    roomSchema
);