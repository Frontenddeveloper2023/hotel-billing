import mongoose from "mongoose";

const checkoutBillSchema = new mongoose.Schema({
  customer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Customer", // Links to your existing Customer model
    required: [true, "Customer reference is required."]
  },
  extraCharges: [
    {
      name: { 
        type: String, 
        required: [true, "Extra charge name is required."], 
        trim: true 
      },
      fees: { 
        type: Number, 
        required: [true, "Fees amount is required."], 
        min: [0, "Fees cannot be negative."] 
      }
    }
  ],
  roomExtraStay: {
    extraTimeStay: {
      before12PM: {
        type: { 
          type: String, 
          enum: ["percentage", "fixed"], 
          default: "percentage" 
        },
        amount: { 
          type: Number, 
          default: 0, 
          min: 0 
        }
      },
      after12PM: {
        type: { 
          type: String, 
          enum: ["percentage", "fixed"], 
          default: "percentage" 
        },
        amount: { 
          type: Number, 
          default: 0, 
          min: 0 
        }
      }
    },
    extraDayStay: {
      numberOfDays: { 
        type: Number, 
        default: 0, 
        min: 0 
      },
      amount: { 
        type: Number, 
        default: 0, 
        min: 0 
      }
    }
  },
  gst: {
    type: Number,
    default: 0
  },
  initialPaidAmount: {
    type: Number,
    default: 0
  },
  grandTotal: {
    type: Number,
    required: [true, "Grand total is required."],
    min: [0, "Grand total cannot be negative."]
  },
  stayStatus: {
    type: String,
    enum: {
      values: ["pending", "vacated"],
      message: "{VALUE} is not a valid stay status"
    },
    default: "pending",
    lowercase: true
  },
  checkoutDateTime: {
    type: Date,
    default: null
  }
}, { timestamps: true });

export default mongoose.model("CheckoutBill", checkoutBillSchema);