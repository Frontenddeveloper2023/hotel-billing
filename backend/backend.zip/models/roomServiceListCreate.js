import mongoose from "mongoose";

const serviceSchema = new mongoose.Schema(
  {
    serviceName: {
      type: String,
      required: [true, "Service name is required"],
      trim: true,
      unique: true, // Optional: prevents duplicate service names
    },
    
    serviceFees: {
      type: Number,
      required: [true, "Service fee is required"],
      min: [0, "Service fee cannot be negative"],
    },
    isEnabled: {
      type: Boolean,
      default: true, // True means active/enabled, false means disabled
    },
  },
  {
    timestamps: true, // Automatically adds createdAt and updatedAt fields
  }
);

export default mongoose.model("ServiceListControle", serviceSchema);