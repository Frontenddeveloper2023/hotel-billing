import mongoose from "mongoose";

// Sub-schema for individual rooms within a multi-room booking
const bookedRoomSchema = new mongoose.Schema({
  roomNumber: { type: String, required: true, trim: true },
  roomType: { type: String, required: true, trim: true },
  bedType: { type: String, required: true, trim: true },
  perNightRoomPrice: { type: Number, required: true, min: 0 }, 
  adults: { type: Number, required: true, min: 1 },
  children: { type: Number, default: 0 },

  // Room-specific services tracked individually per room
  foodServicesDetails: {
    type: [
      {
        foodId: { type: mongoose.Schema.Types.ObjectId, ref: "Food", default: null },
        name: { type: String, default: "", trim: true },
        price: { type: Number, default: 0, min: 0 },
        quantity: { type: Number, default: 1, min: 0 },
        total: { type: Number, default: 0, min: 0 }
      }
    ],
    default: []
  },

  roomServicesDetails: {
    type: [
      {
        serviceId: { type: mongoose.Schema.Types.ObjectId, ref: "RoomService", default: null },
        name: { type: String, default: "", trim: true },
        fees: { type: Number, default: 0, min: 0 },
        quantity: { type: Number, default: 1, min: 0 },
        total: { type: Number, default: 0, min: 0 }
      }
    ],
    default: []
  }
}, { timestamps: true });

const customerSchema = new mongoose.Schema({
  // Personal Information
  customerName: { type: String, required: true },
  phoneNumber: { type: String, required: true },
  alternativePhone: { type: String, default: "" },
  email: { type: String, default: "" },
  address: { type: String, required: true },
  idProofType: { type: String, required: true },
  idProofNumber: { type: String, required: true },

  // Room Information (Supports 1 or multiple rooms booked together)
  rooms: [bookedRoomSchema],

  // Stay Information (Common for all rooms in this booking)
  checkIn: {
    type: Date,
    required: true
  },
  checkInTime: {
    type: String,
    default: ""
  },
  checkOut: {
    type: Date,
    required: true
  },
  checkOutTime: {
    type: String,
    default: ""
  },
  checkoutStatus: {
    type: String,
    enum: ["Staying", "Overstayed", "Checked Out"],
    default: "Staying"
  },

  actualCheckoutDate: {
    type: String,
    default: ""
  },
  actualCheckoutTime: {
    type: String,
    default: ""
  },

  // Payment Information
  initialPaidAmount: { type: Number, default: 0 },
  initialPaidVia: { type: String, default: "Cash" },

}, { timestamps: true });

export default mongoose.model("Customer", customerSchema);