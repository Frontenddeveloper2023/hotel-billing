import mongoose from "mongoose";

const foodSchema = new mongoose.Schema({
  foodName: { 
    type: String, 
    required: [true, "Food name is required."], 
    trim: true 
  },
  description: { 
    type: String, 
    default: "" 
  },
  foodPrice: { 
    type: Number, 
    required: [true, "Food price is required."], 
    min: [0, "Price cannot be negative."] 
  },
  foodQuantity: { 
    type: Number, 
    required: [true, "Food quantity/stock is required."], 
    min: [0, "Quantity cannot be negative."],
    default: 0 
  },
  foodImage: { 
    type: String, 
    default: "" 
  },
}, { timestamps: true });

export default mongoose.model("Food", foodSchema);