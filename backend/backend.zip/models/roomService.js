import mongoose from "mongoose";

const serviceSchema = new mongoose.Schema(
  {
    // Customer who requested the service
    customerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Customer",
      required: true,
    },

    roomNumber: {
      type: String,
      required: [true, "Room number is required."],
      trim: true,
      index: true,
    },

    // Extra Service Details
    serviceName: {
      type: String,
      required: true,
      trim: true,
    },

    serviceFees: {
      type: Number,
      required: true,
      min: 0,
    },

    // Pending → Paid
    paymentStatus: {
      type: String,
      enum: ["Pending", "Paid"],
      default: "Pending",
    },

    serviceDate: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.model("RoomService", serviceSchema);