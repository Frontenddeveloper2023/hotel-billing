import mongoose from "mongoose";

const settingsSchema = new mongoose.Schema({
  companyName: { type: String, required: true },
  gstNumber: { type: String, required: true },
  phoneNumbers: { type: [String], default: [] },
  email: { type: String, required: true },
  companyLogo: { type: String, default: "" },
  address: { type: String, required: true },
  
  // Add these fields so Mongoose allows them to be saved to MongoDB:
  gstCalculationEnabled: { type: Boolean, default: false },
  gstRate: { type: Number, default: 0 },
  
  beforeCheckoutPolicyType: { type: String, default: "percentage" },
  beforeCheckoutValue: { type: Number, default: 0 },
  
  afterCheckoutPolicyType: { type: String, default: "full" },
  afterCheckoutValue: { type: Number, default: 0 },
}, { timestamps: true });

export default mongoose.model("Settings", settingsSchema);