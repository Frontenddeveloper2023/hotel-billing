import Customer from "../models/customers.js";
import { log } from "../util/logger.js";

// =====================================================
// 1. CREATE CUSTOMER (BOOKING)
// =====================================================
export const createCustomer = async (req, res) => {
    try {
        const {
            customerName, phoneNumber, alternativePhone, email, address,
            idProofType, idProofNumber, rooms,
            // Fallback single room fields for backward compatibility
            roomNumber, roomType, bedType, perNightRoomPrice, adults, children,
            checkIn, checkInTime, checkOut, checkOutTime, checkoutStatus, 
            actualCheckoutDate, actualCheckoutTime, initialPaidAmount, initialPaidVia,
        } = req.body;

        // --- Validations ---
        if (!customerName || !customerName.trim()) {
            return res.status(400).json({ success: false, message: "Customer name is required." });
        }
        if (!phoneNumber || !phoneNumber.trim()) {
            return res.status(400).json({ success: false, message: "Phone number is required." });
        }
        if (!address || !address.trim()) {
            return res.status(400).json({ success: false, message: "Address is required." });
        }
        if (!idProofType || !idProofType.trim() || !idProofNumber || !idProofNumber.trim()) {
            return res.status(400).json({ success: false, message: "ID proof type and ID proof number are required." });
        }

        // Handle rooms array or fallback to single room fields
       let processedRooms = rooms;

// Handle rooms coming as JSON string
if (typeof processedRooms === "string") {
    try {
        processedRooms = JSON.parse(processedRooms);
    } catch (error) {
        return res.status(400).json({
            success: false,
            message: "Invalid rooms data.",
        });
    }
}

// Backward compatibility for old single-room booking
if (
    (!Array.isArray(processedRooms) || processedRooms.length === 0) &&
    roomNumber
) {
    processedRooms = [
        {
            roomNumber,
            roomType,
            bedType,
            perNightRoomPrice: Number(perNightRoomPrice || 0),
            adults: Number(adults || 1),
            children:
                children !== undefined
                    ? Number(children)
                    : 0,
            foodServicesDetails: [],
            roomServicesDetails: [],
        },
    ];
}

if (
    !Array.isArray(processedRooms) ||
    processedRooms.length === 0
) {
    return res.status(400).json({
        success: false,
        message: "At least one room must be selected for booking.",
    });
}

       // =====================================================
// VALIDATE EACH ROOM
// =====================================================

for (let index = 0; index < processedRooms.length; index++) {
    const room = processedRooms[index];

    console.log(
        `CREATE CUSTOMER - ROOM ${index + 1}:`,
        JSON.stringify(room, null, 2)
    );

    if (!room || typeof room !== "object") {
        return res.status(400).json({
            success: false,
            message: `Room ${index + 1} information is invalid.`,
        });
    }

    const roomNumber = String(room.roomNumber || "").trim();
    const roomType = String(room.roomType || "").trim();
    const bedType = String(room.bedType || "").trim();

    if (!roomNumber) {
        return res.status(400).json({
            success: false,
            message: `Room ${index + 1}: roomNumber is required.`,
        });
    }

    if (!roomType) {
        return res.status(400).json({
            success: false,
            message: `Room ${index + 1} (${roomNumber}): roomType is required.`,
        });
    }

    if (!bedType) {
        return res.status(400).json({
            success: false,
            message: `Room ${index + 1} (${roomNumber}): bedType is required.`,
        });
    }

    const roomPrice = Number(room.perNightRoomPrice);

    if (!Number.isFinite(roomPrice) || roomPrice < 0) {
        return res.status(400).json({
            success: false,
            message: `Room ${index + 1} (${roomNumber}): invalid per-night room price.`,
        });
    }

    const roomAdults = Number(room.adults);

    if (!Number.isFinite(roomAdults) || roomAdults < 1) {
        return res.status(400).json({
            success: false,
            message: `Room ${index + 1} (${roomNumber}): at least 1 adult is required.`,
        });
    }
}


        if (!checkIn || !checkOut) {
            return res.status(400).json({ success: false, message: "Check-in and Check-out dates are required." });
        }

        const checkInDate = new Date(checkIn);
        const checkOutDate = new Date(checkOut);

        if (isNaN(checkInDate.getTime()) || isNaN(checkOutDate.getTime())) {
            return res.status(400).json({ success: false, message: "Invalid date format provided for check-in or check-out." });
        }
        if (checkInDate >= checkOutDate) {
            return res.status(400).json({ success: false, message: "Check-out date must be later than the check-in date." });
        }
        if (!checkInTime || !String(checkInTime).trim()) {
            return res.status(400).json({ success: false, message: "Check-in time is required." });
        }
        if (!checkOutTime || !String(checkOutTime).trim()) {
            return res.status(400).json({ success: false, message: "Check-out time is required." });
        }


        console.log(
    "=========================================="
);

console.log(
    "CREATE CUSTOMER - ROOMS RECEIVED:"
);

console.log(
    JSON.stringify(processedRooms, null, 2)
);

console.log(
    "ROOM COUNT:",
    processedRooms.length
);

console.log(
    "=========================================="
);

        const formattedRooms = processedRooms.map(room => ({
            roomNumber: String(room.roomNumber).trim(),
            roomType: String(room.roomType).trim(),
            bedType: String(room.bedType).trim(),
            perNightRoomPrice: Number(room.perNightRoomPrice),
            adults: Number(room.adults),
            children: room.children !== undefined ? Number(room.children) : 0,
            foodServicesDetails: room.foodServicesDetails || [],
            roomServicesDetails: room.roomServicesDetails || []
        }));

        const newCustomer = await Customer.create({
            customerName: customerName.trim(),
            phoneNumber: phoneNumber.trim(),
            alternativePhone: alternativePhone ? alternativePhone.trim() : "",
            email: email ? email.trim() : "",
            address: address.trim(),
            idProofType: idProofType.trim(),
            idProofNumber: idProofNumber.trim(),
            rooms: formattedRooms,
            checkIn: checkInDate,
            checkInTime: String(checkInTime).trim(),
            checkOut: checkOutDate,
            checkOutTime: String(checkOutTime).trim(),
            checkoutStatus: checkoutStatus || "Staying",
            actualCheckoutDate: actualCheckoutDate || "",
            actualCheckoutTime: actualCheckoutTime || "",
            initialPaidAmount: initialPaidAmount !== undefined ? Number(initialPaidAmount) : 0,
            initialPaidVia: initialPaidVia ? initialPaidVia.trim() : "Cash",
        });

        const primaryRoomNumber = formattedRooms.map(r => r.roomNumber).join(", ");
        log.info(`Customer booking created successfully for: ${customerName} (Rooms: ${primaryRoomNumber})`);

        return res.status(201).json({
            success: true,
            message: "Customer booking created successfully.",
            data: newCustomer,
        });

    } catch (error) {
        log.error(`Error creating customer record: ${error.message}`);
        if (error.name === "ValidationError") {
            const messages = Object.values(error.errors).map((err) => err.message);
            return res.status(400).json({ success: false, message: `Validation failed: ${messages.join(", ")}` });
        }
        return res.status(500).json({ success: false, message: "An internal server error occurred while creating the customer record." });
    }
};

// =====================================================
// 2. GET ALL CUSTOMERS (with dynamic overstay tagging)
// =====================================================
export const getAllCustomers = async (req, res) => {
    try {
        const customers = await Customer.find().sort({ createdAt: -1 });
        const now = new Date();

        const enhancedCustomers = customers.map(customer => {
            const customerObj = customer.toObject();
            if (customerObj.checkoutStatus === "Staying") {
                const checkOutDate = new Date(customerObj.checkOut);
                if (customerObj.checkOutTime) {
                    const [hours, minutes] = customerObj.checkOutTime.split(":");
                    checkOutDate.setHours(parseInt(hours || 0, 10), parseInt(minutes || 0, 10), 0, 0);
                }
                customerObj.isOverstayed = now > checkOutDate;
            } else {
                customerObj.isOverstayed = false;
            }
            return customerObj;
        });

        return res.status(200).json({
            success: true,
            count: enhancedCustomers.length,
            data: enhancedCustomers,
        });

    } catch (error) {
        log.error(`Error fetching customers list: ${error.message}`);
        return res.status(500).json({ success: false, message: "Failed to fetch customer records." });
    }
};

// =====================================================
// 3. GET SINGLE CUSTOMER BY ID
// =====================================================
export const getCustomerById = async (req, res) => {
    try {
        const { id } = req.params;
        if (!id) return res.status(400).json({ success: false, message: "Customer ID parameter is missing." });

        const customer = await Customer.findById(id);
        if (!customer) return res.status(404).json({ success: false, message: "Customer record not found." });

        return res.status(200).json({ success: true, data: customer });
    } catch (error) {
        log.error(`Error fetching customer by ID (${req.params.id}): ${error.message}`);
        if (error.name === "CastError") return res.status(400).json({ success: false, message: "Invalid customer ID format." });
        return res.status(500).json({ success: false, message: "An internal server error occurred." });
    }
};

// =====================================================
// 4. UPDATE CUSTOMER
// =====================================================
export const updateCustomer = async (req, res) => {
    try {
        const { id } = req.params;
        if (!id) return res.status(400).json({ success: false, message: "Customer ID parameter is missing." });

        const existingCustomer = await Customer.findById(id);
        if (!existingCustomer) return res.status(404).json({ success: false, message: "Customer record not found." });

        const {
            customerName, phoneNumber, alternativePhone, email, address,
            idProofType, idProofNumber, rooms,
            roomNumber, roomType, bedType, perNightRoomPrice, adults, children,
            checkIn, checkInTime, checkOut, checkOutTime, initialPaidAmount, initialPaidVia,
            checkoutStatus, actualCheckoutDate, actualCheckoutTime
        } = req.body;

        const checkInVal = checkIn || existingCustomer.checkIn;
        const checkOutVal = checkOut || existingCustomer.checkOut;

        if (new Date(checkInVal) >= new Date(checkOutVal)) {
            return res.status(400).json({ success: false, message: "Check-out date must be later than the check-in date." });
        }

        const updateData = {};
        if (customerName) updateData.customerName = customerName.trim();
        if (phoneNumber) updateData.phoneNumber = phoneNumber.trim();
        if (alternativePhone !== undefined) updateData.alternativePhone = alternativePhone.trim();
        if (email !== undefined) updateData.email = email.trim();
        if (address) updateData.address = address.trim();
        if (idProofType) updateData.idProofType = idProofType.trim();
        if (idProofNumber) updateData.idProofNumber = idProofNumber.trim();

        // Handle room updates
        if (rooms && Array.isArray(rooms)) {
            updateData.rooms = rooms.map(room => ({
                roomNumber: String(room.roomNumber).trim(),
                roomType: String(room.roomType).trim(),
                bedType: String(room.bedType).trim(),
                perNightRoomPrice: Number(room.perNightRoomPrice),
                adults: Number(room.adults),
                children: room.children !== undefined ? Number(room.children) : 0,
                foodServicesDetails: room.foodServicesDetails || [],
                roomServicesDetails: room.roomServicesDetails || []
            }));
        } else if (roomNumber || roomType || bedType) {
            // Fallback single room update
            const updatedRoom = {
                roomNumber: roomNumber || existingCustomer.rooms?.[0]?.roomNumber,
                roomType: roomType || existingCustomer.rooms?.[0]?.roomType,
                bedType: bedType || existingCustomer.rooms?.[0]?.bedType,
                perNightRoomPrice: perNightRoomPrice !== undefined ? Number(perNightRoomPrice) : existingCustomer.rooms?.[0]?.perNightRoomPrice,
                adults: adults !== undefined ? Number(adults) : existingCustomer.rooms?.[0]?.adults,
                children: children !== undefined ? Number(children) : (existingCustomer.rooms?.[0]?.children || 0),
                foodServicesDetails: existingCustomer.rooms?.[0]?.foodServicesDetails || [],
                roomServicesDetails: existingCustomer.rooms?.[0]?.roomServicesDetails || []
            };
            updateData.rooms = [updatedRoom];
        }

        if (checkIn) updateData.checkIn = new Date(checkIn);
        if (checkInTime) updateData.checkInTime = String(checkInTime).trim();
        if (checkOut) updateData.checkOut = new Date(checkOut);
        if (checkOutTime) updateData.checkOutTime = String(checkOutTime).trim();
        if (initialPaidAmount !== undefined) updateData.initialPaidAmount = Number(initialPaidAmount);
        if (initialPaidVia) updateData.initialPaidVia = initialPaidVia.trim();
        if (checkoutStatus !== undefined) updateData.checkoutStatus = String(checkoutStatus).trim();
        if (actualCheckoutDate !== undefined) updateData.actualCheckoutDate = String(actualCheckoutDate).trim();
        if (actualCheckoutTime !== undefined) updateData.actualCheckoutTime = String(actualCheckoutTime).trim();

        const updatedCustomer = await Customer.findByIdAndUpdate(
            id,
            { $set: updateData },
            { new: true, runValidators: true }
        );

        return res.status(200).json({
            success: true,
            message: "Customer details updated successfully.",
            data: updatedCustomer,
        });

    } catch (error) {
        log.error(`Error updating customer record: ${error.message}`);
        if (error.name === "ValidationError") {
            const messages = Object.values(error.errors).map(err => err.message);
            return res.status(400).json({ success: false, message: `Validation failed: ${messages.join(", ")}` });
        }
        if (error.name === "CastError") {
            return res.status(400).json({ success: false, message: "Invalid customer ID format." });
        }
        return res.status(500).json({ success: false, message: "An internal server error occurred." });
    }
};

// =====================================================
// 5. CHECK OVERSTAYS
// =====================================================
export const getOverstayCustomers = async (req, res) => {
    try {
        const now = new Date();
        const activeCustomers = await Customer.find({ checkoutStatus: "Staying" });

        const overstayedList = activeCustomers.filter(customer => {
            const checkOutDate = new Date(customer.checkOut);
            if (customer.checkOutTime) {
                const [hours, minutes] = customer.checkOutTime.split(":");
                checkOutDate.setHours(parseInt(hours || 0, 10), parseInt(minutes || 0, 10), 0, 0);
            }
            return now > checkOutDate;
        });

        return res.status(200).json({
            success: true,
            count: overstayedList.length,
            data: overstayedList,
        });
    } catch (error) {
        log.error(`Error checking overstay customers: ${error.message}`);
        return res.status(500).json({ success: false, message: "Failed to process overstay evaluations." });
    }
};

// =====================================================
// 6. DELETE CUSTOMER
// =====================================================
export const deleteCustomer = async (req, res) => {
    try {
        const { id } = req.params;
        if (!id) return res.status(400).json({ success: false, message: "Customer ID parameter is missing." });

        const customer = await Customer.findById(id);
        if (!customer) return res.status(404).json({ success: false, message: "Customer record not found." });

        await Customer.findByIdAndDelete(id);
        log.info(`Customer record deleted successfully: ${id}`);

        return res.status(200).json({ success: true, message: "Customer record deleted successfully." });
    } catch (error) {
        log.error(`Error deleting customer record (${req.params.id}): ${error.message}`);
        if (error.name === "CastError") return res.status(400).json({ success: false, message: "Invalid customer ID format." });
        return res.status(500).json({ success: false, message: "An internal server error occurred." });
    }
};