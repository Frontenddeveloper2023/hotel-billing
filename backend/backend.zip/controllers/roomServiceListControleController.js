import mongoose from "mongoose";
import ServiceListControle from "../models/roomServiceListCreate.js";
import { log } from "../util/logger.js";

// ============================================================
// ADD SERVICE
// ============================================================

const createService = async (req, res) => {
    try {
        const {
            serviceName,
            serviceFees,
            isEnabled,
        } = req.body;

        // ----------------------------------------------------
        // SERVICE NAME VALIDATION
        // ----------------------------------------------------

        if (
            !serviceName ||
            typeof serviceName !== "string" ||
            !serviceName.trim()
        ) {
            log(
                "ERROR",
                "Create Service failed: Service name is required"
            );

            return res.status(400).json({
                message: "Service name is required",
            });
        }

        // ----------------------------------------------------
        // SERVICE FEES VALIDATION
        // ----------------------------------------------------

        if (
            serviceFees === undefined ||
            serviceFees === null ||
            serviceFees === ""
        ) {
            log(
                "ERROR",
                "Create Service failed: Service fee is required"
            );

            return res.status(400).json({
                message: "Service fee is required",
            });
        }

        const fee = Number(serviceFees);

        if (
            !Number.isFinite(fee) ||
            fee < 0
        ) {
            log(
                "ERROR",
                `Create Service failed: Invalid service fee - ${serviceFees}`
            );

            return res.status(400).json({
                message: "Service fee must be a valid number greater than or equal to 0",
            });
        }

        // ----------------------------------------------------
        // IS ENABLED VALIDATION (OPTIONAL)
        // ----------------------------------------------------

        let serviceStatus = true;
        if (isEnabled !== undefined) {
            if (typeof isEnabled !== "boolean") {
                log(
                    "ERROR",
                    `Create Service failed: Invalid isEnabled type - ${typeof isEnabled}`
                );

                return res.status(400).json({
                    message: "isEnabled must be a boolean value",
                });
            }
            serviceStatus = isEnabled;
        }

        // ----------------------------------------------------
        // CHECK DUPLICATE SERVICE
        // ----------------------------------------------------

        const existingService =
            await ServiceListControle.findOne({
                serviceName: serviceName.trim(),
            });

        if (existingService) {
            log(
                "ERROR",
                `Create Service failed: Service name already exists - ${serviceName.trim()}`
            );

            return res.status(409).json({
                message: "Service name already exists",
            });
        }

        // ----------------------------------------------------
        // CREATE SERVICE
        // ----------------------------------------------------

        const service =
            await ServiceListControle.create({
                serviceName: serviceName.trim(),
                serviceFees: fee,
                isEnabled: serviceStatus,
            });

        log(
            "INFO",
            `Service added successfully: ${service.serviceName}`
        );

        return res.status(201).json({
            message: "Service added successfully",
            service,
        });

    } catch (error) {
        log(
            "ERROR",
            `Create Service error: ${error.message}`
        );

        console.error(
            "Create Service error:",
            error
        );

        return res.status(500).json({
            message: "Failed to add service",
        });
    }
};

// ============================================================
// GET ALL SERVICES
// ============================================================

const getAllServices = async (req, res) => {
    try {
        const services =
            await ServiceListControle.find()
                .sort({
                    serviceName: 1,
                });

        log(
            "INFO",
            `Services fetched successfully: ${services.length} services`
        );

        return res.status(200).json({
            message: "Services fetched successfully",
            services,
        });

    } catch (error) {
        log(
            "ERROR",
            `Get all services error: ${error.message}`
        );

        console.error(
            "Get all services error:",
            error
        );

        return res.status(500).json({
            message: "Failed to fetch services",
        });
    }
};

// ============================================================
// GET SINGLE SERVICE
// ============================================================

const getService = async (req, res) => {
    try {
        const { id } = req.params;

        // ----------------------------------------------------
        // OBJECT ID VALIDATION
        // ----------------------------------------------------

        if (
            !mongoose.Types.ObjectId.isValid(id)
        ) {
            log(
                "ERROR",
                `Get Service failed: Invalid service ID - ${id}`
            );

            return res.status(400).json({
                message: "Invalid service ID",
            });
        }

        // ----------------------------------------------------
        // FIND SERVICE
        // ----------------------------------------------------

        const service =
            await ServiceListControle.findById(id);

        if (!service) {
            log(
                "ERROR",
                `Get Service failed: Service not found - ${id}`
            );

            return res.status(404).json({
                message: "Service not found",
            });
        }

        log(
            "INFO",
            `Service fetched successfully: ${service.serviceName}`
        );

        return res.status(200).json({
            message: "Service fetched successfully",
            service,
        });

    } catch (error) {
        log(
            "ERROR",
            `Get Service error: ${error.message}`
        );

        console.error(
            "Get Service error:",
            error
        );

        return res.status(500).json({
            message: "Failed to fetch service",
        });
    }
};

// ============================================================
// UPDATE SERVICE
// ============================================================

const updateService = async (req, res) => {
    try {
        const { id } = req.params;

        const {
            serviceName,
            serviceFees,
            isEnabled,
        } = req.body;

        // ----------------------------------------------------
        // OBJECT ID VALIDATION
        // ----------------------------------------------------

        if (
            !mongoose.Types.ObjectId.isValid(id)
        ) {
            log(
                "ERROR",
                `Update Service failed: Invalid service ID - ${id}`
            );

            return res.status(400).json({
                message: "Invalid service ID",
            });
        }

        // ----------------------------------------------------
        // FIND SERVICE
        // ----------------------------------------------------

        const existingService =
            await ServiceListControle.findById(id);

        if (!existingService) {
            log(
                "ERROR",
                `Update Service failed: Service not found - ${id}`
            );

            return res.status(404).json({
                message: "Service not found",
            });
        }

        // ----------------------------------------------------
        // SERVICE NAME VALIDATION
        // ----------------------------------------------------

        if (serviceName !== undefined) {
            if (
                typeof serviceName !== "string" ||
                !serviceName.trim()
            ) {
                log(
                    "ERROR",
                    `Update Service failed: Invalid service name - ${id}`
                );

                return res.status(400).json({
                    message: "Service name cannot be empty",
                });
            }

            const duplicateService =
                await ServiceListControle.findOne({
                    serviceName: serviceName.trim(),
                    _id: { $ne: id },
                });

            if (duplicateService) {
                log(
                    "ERROR",
                    `Update Service failed: Service name already exists - ${serviceName.trim()}`
                );

                return res.status(409).json({
                    message: "Service name already exists",
                });
            }

            existingService.serviceName =
                serviceName.trim();
        }

        // ----------------------------------------------------
        // SERVICE FEES VALIDATION
        // ----------------------------------------------------

        if (serviceFees !== undefined) {
            if (
                serviceFees === "" ||
                serviceFees === null
            ) {
                log(
                    "ERROR",
                    `Update Service failed: Price is empty - ${id}`
                );

                return res.status(400).json({
                    message: "Service fee is required",
                });
            }

            const fee = Number(serviceFees);

            if (
                !Number.isFinite(fee) ||
                fee < 0
            ) {
                log(
                    "ERROR",
                    `Update Service failed: Invalid fee - ${serviceFees}`
                );

                return res.status(400).json({
                    message: "Service fee must be a valid number greater than or equal to 0",
                });
            }

            existingService.serviceFees = fee;
        }

        // ----------------------------------------------------
        // IS ENABLED VALIDATION
        // ----------------------------------------------------

        if (isEnabled !== undefined) {
            if (typeof isEnabled !== "boolean") {
                log(
                    "ERROR",
                    `Update Service failed: Invalid isEnabled type - ${typeof isEnabled}`
                );

                return res.status(400).json({
                    message: "isEnabled must be a boolean value",
                });
            }

            existingService.isEnabled = isEnabled;
        }

        // ----------------------------------------------------
        // SAVE UPDATED SERVICE
        // ----------------------------------------------------

        const updatedService =
            await existingService.save();

        log(
            "INFO",
            `Service updated successfully: ${updatedService.serviceName}`
        );

        return res.status(200).json({
            message: "Service updated successfully",
            service: updatedService,
        });

    } catch (error) {
        log(
            "ERROR",
            `Update Service error: ${error.message}`
        );

        console.error(
            "Update Service error:",
            error
        );

        return res.status(500).json({
            message: "Failed to update service",
        });
    }
};

// ============================================================
// DELETE SERVICE
// ============================================================

const deleteService = async (req, res) => {
    try {
        const { id } = req.params;

        // ----------------------------------------------------
        // OBJECT ID VALIDATION
        // ----------------------------------------------------

        if (
            !mongoose.Types.ObjectId.isValid(id)
        ) {
            log(
                "ERROR",
                `Delete Service failed: Invalid service ID - ${id}`
            );

            return res.status(400).json({
                message: "Invalid service ID",
            });
        }

        // ----------------------------------------------------
        // FIND SERVICE
        // ----------------------------------------------------

        const service =
            await ServiceListControle.findById(id);

        if (!service) {
            log(
                "ERROR",
                `Delete Service failed: Service not found - ${id}`
            );

            return res.status(404).json({
                message: "Service not found",
            });
        }

        // ----------------------------------------------------
        // DELETE SERVICE
        // ----------------------------------------------------

        await ServiceListControle.findByIdAndDelete(id);

        log(
            "INFO",
            `Service deleted successfully: ${service.serviceName}`
        );

        return res.status(200).json({
            message: "Service deleted successfully",
        });

    } catch (error) {
        log(
            "ERROR",
            `Delete Service error: ${error.message}`
        );

        console.error(
            "Delete Service error:",
            error
        );

        return res.status(500).json({
            message: "Failed to delete service",
        });
    }
};

// ============================================================
// EXPORT
// ============================================================

export {
    createService,
    getAllServices,
    getService,
    updateService,
    deleteService,
};