import Settings from "../models/settings.js";
import fs from "fs";
import path from "path";

// GET Settings
export const getSettings = async (req, res) => {
    try {
        let settings = await Settings.findOne();
        if (!settings) {
            settings = await Settings.create({
                companyName: "SS Residency",
                gstNumber: "29GGGGG1314R9Z6",
                phoneNumbers: "+91 126766488, 7800008009",
                email: "contact@ssresidency.com",
                hotelAddress: "123, MG Road, Bangalore - 560001",
                gstCalculationEnabled: false,
                gstRate: 0,
                beforeCheckoutPolicyType: "percentage",
                beforeCheckoutValue: 0,
                afterCheckoutPolicyType: "full",
                afterCheckoutValue: 0,
            });
        }
        res.status(200).json({ success: true, data: settings });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// UPDATE or CREATE Settings
export const updateSettings = async (req, res) => {
    try {
        let settings = await Settings.findOne();
        
        // Safely evaluate boolean from FormData string/boolean
        const isGstEnabled = req.body.enableGst === 'true' || req.body.enableGst === true;

        const updateData = {
            companyName: req.body.companyName,
            gstNumber: req.body.gstNumber,
            phoneNumbers: req.body.phone,
            email: req.body.email,
            hotelAddress: req.body.address,
            
            // GST fields
            gstCalculationEnabled: isGstEnabled,
            gstRate: isGstEnabled && req.body.gstPercentage ? Number(req.body.gstPercentage) : 0,

            // Checkout Rules fields
            beforeCheckoutPolicyType: req.body.before12PmRateType,
            beforeCheckoutValue: req.body.before12PmValue !== undefined && req.body.before12PmValue !== "" ? Number(req.body.before12PmValue) : 0,
            afterCheckoutPolicyType: req.body.after12PmRateType,
            afterCheckoutValue: req.body.after12PmValue !== undefined && req.body.after12PmValue !== "" ? Number(req.body.after12PmValue) : 0,
        };

        // Handle file upload via multer
        if (req.file) {
            const newLogoPath = `uploads/settings/${req.file.filename}`;
            if (settings && settings.companyLogo) {
                const oldFullPath = path.join(process.cwd(), settings.companyLogo);
                if (fs.existsSync(oldFullPath)) {
                    fs.unlinkSync(oldFullPath);
                }
            }
            updateData.companyLogo = newLogoPath;
        } else if (req.body.removeLogo === 'true' || req.body.removeLogo === true) {
            if (settings && settings.companyLogo) {
                const oldFullPath = path.join(process.cwd(), settings.companyLogo);
                if (fs.existsSync(oldFullPath)) {
                    fs.unlinkSync(oldFullPath);
                }
            }
            updateData.companyLogo = "";
        }

        if (!settings) {
            settings = await Settings.create(updateData);
        } else {
            settings = await Settings.findOneAndUpdate({}, updateData, { new: true, runValidators: true });
        }

        res.status(200).json({
            success: true,
            message: "Settings updated successfully",
            data: settings,
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};