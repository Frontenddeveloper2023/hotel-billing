import { log } from "../util/logger.js";
import Service from "../models/roomService.js";
import Customer from "../models/customers.js";


// =====================================================
// 1. ADD EXTRA SERVICE
// =====================================================
export const addService = async (req, res) => {
    try {
        const {
            customerId,
            roomNumber,
            serviceName,
            serviceFees,
            paymentStatus,
        } = req.body;

        log(
            `[ROOM SERVICE] Add request | Customer: ${customerId} | Room: ${roomNumber}`
        );

        // -------------------------------------------------
        // VALIDATE CUSTOMER ID
        // -------------------------------------------------
        if (
            !customerId ||
            !String(customerId).trim()
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Customer ID is required.",
            });
        }

        // -------------------------------------------------
        // ⭐ VALIDATE ROOM NUMBER
        // -------------------------------------------------
        if (
            !roomNumber ||
            !String(roomNumber).trim()
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Room number is required.",
            });
        }

        // -------------------------------------------------
        // VALIDATE SERVICE NAME
        // -------------------------------------------------
        if (
            !serviceName ||
            !String(serviceName).trim()
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Service name is required.",
            });
        }

        // -------------------------------------------------
        // VALIDATE SERVICE FEES
        // -------------------------------------------------
        if (
            serviceFees === undefined ||
            serviceFees === null ||
            serviceFees === ""
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Service fees are required.",
            });
        }

        const parsedFees =
            Number(serviceFees);

        if (
            !Number.isFinite(parsedFees) ||
            parsedFees < 0
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Service fees must be a valid number greater than or equal to 0.",
            });
        }

        // -------------------------------------------------
        // FIND CUSTOMER
        // -------------------------------------------------
        const customerExists =
            await Customer.findById(
                customerId
            );

        if (!customerExists) {
            log(
                `[ROOM SERVICE] Customer not found: ${customerId}`
            );

            return res.status(404).json({
                success: false,
                message:
                    "Customer not found.",
            });
        }

        // -------------------------------------------------
        // ⭐ VERIFY ROOM BELONGS TO CUSTOMER
        // -------------------------------------------------
        const selectedRoom =
            customerExists.rooms?.find(
                (room) =>
                    String(
                        room.roomNumber
                    ).trim() ===
                    String(
                        roomNumber
                    ).trim()
            );

        if (!selectedRoom) {
            return res.status(404).json({
                success: false,
                message:
                    `Room ${roomNumber} is not booked by this customer.`,
            });
        }

        // -------------------------------------------------
        // CREATE SERVICE
        // -------------------------------------------------
        const newService =
            new Service({
                customerId:
                    customerExists._id,

                // ⭐ SAVE ROOM NUMBER
                roomNumber:
                    String(roomNumber).trim(),

                serviceName:
                    String(
                        serviceName
                    ).trim(),

                serviceFees:
                    parsedFees,

                // Always start Pending
                paymentStatus:
                    paymentStatus === "Paid"
                        ? "Paid"
                        : "Pending",
            });

        const savedService =
            await newService.save();

        log(
            `[ROOM SERVICE] Created | ID: ${savedService._id} | Customer: ${customerId} | Room: ${roomNumber}`
        );

        return res.status(201).json({
            success: true,
            message:
                "Extra service added successfully.",
            data: savedService,
        });

    } catch (error) {
        log(
            `[ROOM SERVICE] Error in addService: ${error.message}`
        );

        if (error.name === "ValidationError") {
            const messages =
                Object.values(
                    error.errors
                ).map(
                    (err) => err.message
                );

            return res.status(400).json({
                success: false,
                message:
                    `Validation failed: ${messages.join(", ")}`,
            });
        }

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid customer ID.",
            });
        }

        return res.status(500).json({
            success: false,
            message:
                error.message ||
                "Failed to add extra service.",
        });
    }
};


// =====================================================
// 2. GET ALL SERVICES
// =====================================================
export const getAllServices = async (
    req,
    res
) => {
    try {
        log(
            "Fetching all extra services."
        );

        const services =
            await Service.find()
                .populate(
                    "customerId",
                    "customerName phoneNumber"
                )
                .sort({
                    createdAt: -1,
                });

        return res.status(200).json({
            success: true,
            count: services.length,
            data: services,
        });

    } catch (error) {
        log(
            `Error in getAllServices: ${error.message}`
        );

        return res.status(500).json({
            success: false,
            message:
                error.message ||
                "Failed to fetch services.",
        });
    }
};


// =====================================================
// 3. GET SERVICES FOR CUSTOMER
//
// Optional:
// ?roomNumber=104
//
// With roomNumber:
// → only Room 104 services
//
// Without roomNumber:
// → all customer's services
// =====================================================
export const getServicesByCustomer = async (
    req,
    res
) => {
    try {
        const { customerId } =
            req.params;

        const roomNumber =
            req.query.roomNumber;

        if (!customerId) {
            return res.status(400).json({
                success: false,
                message:
                    "Customer ID parameter is required.",
            });
        }

        // -------------------------------------------------
        // BUILD QUERY
        // -------------------------------------------------
        const query = {
            customerId,
        };

        // ⭐ ROOM-SPECIFIC FILTER
        if (
            roomNumber !== undefined &&
            String(roomNumber).trim()
        ) {
            query.roomNumber =
                String(
                    roomNumber
                ).trim();
        }

        const services =
            await Service.find(query)
                .populate(
                    "customerId"
                )
                .sort({
                    createdAt: -1,
                });

        log(
            `[ROOM SERVICE] Retrieved ${services.length} records | Customer: ${customerId} | Room: ${roomNumber || "ALL"}`
        );

        return res.status(200).json({
            success: true,
            count: services.length,
            data: services,
        });

    } catch (error) {
        log(
            `Error in getServicesByCustomer: ${error.message}`
        );

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid customer ID format.",
            });
        }

        return res.status(500).json({
            success: false,
            message:
                error.message ||
                "Failed to fetch customer services.",
        });
    }
};


// =====================================================
// 4. UPDATE SERVICE
//
// Pending → Paid
// =====================================================
export const updateService = async (
    req,
    res
) => {
    try {
        const { id } =
            req.params;

        log(
            "=================================================="
        );

        log(
            `[ROOM SERVICE UPDATE] Service ID: ${id}`
        );

        log(
            `[ROOM SERVICE UPDATE] Request body: ${JSON.stringify(req.body)}`
        );

        // -------------------------------------------------
        // VALIDATE ID
        // -------------------------------------------------
        if (!id) {
            return res.status(400).json({
                success: false,
                message:
                    "Service ID is required.",
            });
        }

        // -------------------------------------------------
        // FIND EXISTING SERVICE
        // -------------------------------------------------
        const existingService =
            await Service.findById(id);

        if (!existingService) {
            return res.status(404).json({
                success: false,
                message:
                    "Service record not found.",
            });
        }

        const updateData = {};

        // -------------------------------------------------
        // SERVICE NAME
        // -------------------------------------------------
        if (
            req.body.serviceName !==
            undefined
        ) {
            updateData.serviceName =
                String(
                    req.body.serviceName
                ).trim();
        }

        // -------------------------------------------------
        // SERVICE FEES
        // -------------------------------------------------
        if (
            req.body.serviceFees !==
            undefined
        ) {
            const parsedFees =
                Number(
                    req.body.serviceFees
                );

            if (
                !Number.isFinite(
                    parsedFees
                ) ||
                parsedFees < 0
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Service fees must be a valid number.",
                });
            }

            updateData.serviceFees =
                parsedFees;
        }

        // -------------------------------------------------
        // ⭐ ROOM NUMBER
        // -------------------------------------------------
        if (
            req.body.roomNumber !==
            undefined
        ) {
            const newRoomNumber =
                String(
                    req.body.roomNumber
                ).trim();

            if (!newRoomNumber) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Room number cannot be empty.",
                });
            }

            updateData.roomNumber =
                newRoomNumber;
        }

        // -------------------------------------------------
        // PAYMENT STATUS
        // -------------------------------------------------
        if (
            req.body.paymentStatus !==
            undefined
        ) {
            if (
                ![
                    "Pending",
                    "Paid",
                ].includes(
                    req.body.paymentStatus
                )
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "paymentStatus must be either Pending or Paid.",
                });
            }

            updateData.paymentStatus =
                req.body.paymentStatus;
        }

        // -------------------------------------------------
        // UPDATE DATABASE
        // -------------------------------------------------
        const updatedService =
            await Service.findByIdAndUpdate(
                id,
                {
                    $set: updateData,
                },
                {
                    new: true,
                    runValidators: true,
                }
            );

        log(
            `[ROOM SERVICE UPDATE] Updated status: ${updatedService.paymentStatus}`
        );

        log(
            `[ROOM SERVICE UPDATE] Service ${id} updated successfully.`
        );

        log(
            "=================================================="
        );

        return res.status(200).json({
            success: true,
            message:
                "Service updated successfully.",
            data: updatedService,
        });

    } catch (error) {
        log(
            `[ROOM SERVICE UPDATE] ERROR: ${error.message}`
        );

        if (error.name === "ValidationError") {
            const messages =
                Object.values(
                    error.errors
                ).map(
                    (err) => err.message
                );

            return res.status(400).json({
                success: false,
                message:
                    `Validation failed: ${messages.join(", ")}`,
            });
        }

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid service ID.",
            });
        }

        return res.status(500).json({
            success: false,
            message:
                error.message ||
                "Failed to update service.",
        });
    }
};


// =====================================================
// 5. DELETE SERVICE
// =====================================================
export const deleteService = async (
    req,
    res
) => {
    try {
        const { id } =
            req.params;

        log(
            `Delete request received for service ID: ${id}`
        );

        const deletedService =
            await Service.findByIdAndDelete(
                id
            );

        if (!deletedService) {
            return res.status(404).json({
                success: false,
                message:
                    "Service record not found.",
            });
        }

        log(
            `Service deleted successfully: ${id}`
        );

        return res.status(200).json({
            success: true,
            message:
                "Service deleted successfully.",
        });

    } catch (error) {
        log(
            `Error in deleteService: ${error.message}`
        );

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid service ID.",
            });
        }

        return res.status(500).json({
            success: false,
            message:
                error.message ||
                "Failed to delete service.",
        });
    }
};