import mongoose from "mongoose";

import Room from "../models/room.js";

import { log } from "../util/logger.js";


// ============================================================
// ADD ROOM
// ============================================================

const addRoom = async (req, res) => {
    try {
        const {
            roomNumber,
            roomType,
            bedType,
            pricePerNight,
            status,
        } = req.body;


        // ----------------------------------------------------
        // ROOM NUMBER
        // ----------------------------------------------------

        if (
            !roomNumber ||
            typeof roomNumber !== "string" ||
            !roomNumber.trim()
        ) {
            log(
                "ERROR",
                "Add Room failed: Room number is required"
            );

            return res.status(400).json({
                message: "Room number is required",
            });
        }


        // ----------------------------------------------------
        // ROOM TYPE
        // ----------------------------------------------------

        if (
            !roomType ||
            typeof roomType !== "string" ||
            !roomType.trim()
        ) {
            log(
                "ERROR",
                "Add Room failed: Room type is required"
            );

            return res.status(400).json({
                message: "Room type is required",
            });
        }


        // ----------------------------------------------------
        // BED TYPE
        // ----------------------------------------------------

        if (
            !bedType ||
            typeof bedType !== "string" ||
            !bedType.trim()
        ) {
            log(
                "ERROR",
                "Add Room failed: Bed type is required"
            );

            return res.status(400).json({
                message: "Bed type is required",
            });
        }


        // ----------------------------------------------------
        // PRICE
        // ----------------------------------------------------

        if (
            pricePerNight === undefined ||
            pricePerNight === null ||
            pricePerNight === ""
        ) {
            log(
                "ERROR",
                "Add Room failed: Price per night is required"
            );

            return res.status(400).json({
                message: "Price per night is required",
            });
        }


        const price = Number(
            pricePerNight
        );


        if (
            !Number.isFinite(price) ||
            price <= 0
        ) {
            log(
                "ERROR",
                `Add Room failed: Invalid price per night - ${pricePerNight}`
            );

            return res.status(400).json({
                message:
                    "Price per night must be a valid number greater than 0",
            });
        }


        // ----------------------------------------------------
        // ROOM TYPE VALIDATION
        // ----------------------------------------------------

        const allowedRoomTypes = [
            "AC",
            "Non-AC",
        ];


        if (
            !allowedRoomTypes.includes(
                roomType.trim()
            )
        ) {
            log(
                "ERROR",
                `Add Room failed: Invalid room type - ${roomType}`
            );

            return res.status(400).json({
                message:
                    "Room type must be AC or Non-AC",
            });
        }


        // ----------------------------------------------------
        // BED TYPE VALIDATION
        // ----------------------------------------------------

        const allowedBedTypes = [
            "Single Bed",
            "2 Bed",
            "3 Bed",
        ];


        if (
            !allowedBedTypes.includes(
                bedType.trim()
            )
        ) {
            log(
                "ERROR",
                `Add Room failed: Invalid bed type - ${bedType}`
            );

            return res.status(400).json({
                message:
                    "Bed type must be Single Bed, 2 Bed or 3 Bed",
            });
        }


        // ----------------------------------------------------
        // STATUS
        // ----------------------------------------------------

        const roomStatus =
            status || "available";


        const allowedStatuses = [
            "available",
            "occupied",
        ];


        if (
            !allowedStatuses.includes(
                roomStatus
            )
        ) {
            log(
                "ERROR",
                `Add Room failed: Invalid room status - ${roomStatus}`
            );

            return res.status(400).json({
                message:
                    "Room status must be available or occupied",
            });
        }


        // ----------------------------------------------------
        // CHECK DUPLICATE ROOM
        // ----------------------------------------------------

        const existingRoom =
            await Room.findOne({
                roomNumber:
                    roomNumber.trim(),
            });


        if (existingRoom) {
            log(
                "ERROR",
                `Add Room failed: Room number already exists - ${roomNumber.trim()}`
            );

            return res.status(409).json({
                message:
                    "Room number already exists",
            });
        }


        // ----------------------------------------------------
        // CREATE ROOM
        // ----------------------------------------------------

        const room =
            await Room.create({
                roomNumber:
                    roomNumber.trim(),

                roomType:
                    roomType.trim(),

                bedType:
                    bedType.trim(),

                pricePerNight:
                    price,

                status:
                    roomStatus,
            });


        log(
            "INFO",
            `Room added successfully: ${room.roomNumber}`
        );


        return res.status(201).json({
            message:
                "Room added successfully",

            room,
        });


    } catch (error) {

        log(
            "ERROR",
            `Add Room error: ${error.message}`
        );


        console.error(
            "Add Room error:",
            error
        );


        return res.status(500).json({
            message:
                "Failed to add room",
        });
    }
};



// ============================================================
// GET ALL ROOMS
// ============================================================

const getAllRooms = async (req, res) => {
    try {

        const rooms =
            await Room.find()
                .sort({
                    roomNumber: 1,
                });


        log(
            "INFO",
            `Rooms fetched successfully: ${rooms.length} rooms`
        );


        return res.status(200).json({
            message:
                "Rooms fetched successfully",

            rooms,
        });


    } catch (error) {

        log(
            "ERROR",
            `Get all rooms error: ${error.message}`
        );


        console.error(
            "Get all rooms error:",
            error
        );


        return res.status(500).json({
            message:
                "Failed to fetch rooms",
        });
    }
};



// ============================================================
// GET SINGLE ROOM
// ============================================================

const getRoom = async (req, res) => {
    try {

        const {
            id,
        } = req.params;


        // ----------------------------------------------------
        // OBJECT ID VALIDATION
        // ----------------------------------------------------

        if (
            !mongoose.Types.ObjectId.isValid(
                id
            )
        ) {
            log(
                "ERROR",
                `Get Room failed: Invalid room ID - ${id}`
            );

            return res.status(400).json({
                message:
                    "Invalid room ID",
            });
        }


        // ----------------------------------------------------
        // FIND ROOM
        // ----------------------------------------------------

        const room =
            await Room.findById(id);


        if (!room) {
            log(
                "ERROR",
                `Get Room failed: Room not found - ${id}`
            );

            return res.status(404).json({
                message:
                    "Room not found",
            });
        }


        log(
            "INFO",
            `Room fetched successfully: ${room.roomNumber}`
        );


        return res.status(200).json({
            message:
                "Room fetched successfully",

            room,
        });


    } catch (error) {

        log(
            "ERROR",
            `Get Room error: ${error.message}`
        );


        console.error(
            "Get Room error:",
            error
        );


        return res.status(500).json({
            message:
                "Failed to fetch room",
        });
    }
};



// ============================================================
// UPDATE ROOM
// ============================================================

const updateRoom = async (req, res) => {
    try {

        const {
            id,
        } = req.params;


        const {
            roomNumber,
            roomType,
            bedType,
            pricePerNight,
            status,
        } = req.body;


        // ----------------------------------------------------
        // OBJECT ID VALIDATION
        // ----------------------------------------------------

        if (
            !mongoose.Types.ObjectId.isValid(
                id
            )
        ) {
            log(
                "ERROR",
                `Update Room failed: Invalid room ID - ${id}`
            );

            return res.status(400).json({
                message:
                    "Invalid room ID",
            });
        }


        // ----------------------------------------------------
        // FIND ROOM
        // ----------------------------------------------------

        const existingRoom =
            await Room.findById(id);


        if (!existingRoom) {
            log(
                "ERROR",
                `Update Room failed: Room not found - ${id}`
            );

            return res.status(404).json({
                message:
                    "Room not found",
            });
        }


        // ----------------------------------------------------
        // ROOM NUMBER VALIDATION
        // ----------------------------------------------------

        if (
            roomNumber !== undefined
        ) {

            if (
                typeof roomNumber !==
                    "string" ||
                !roomNumber.trim()
            ) {
                log(
                    "ERROR",
                    `Update Room failed: Invalid room number - ${id}`
                );

                return res.status(400).json({
                    message:
                        "Room number cannot be empty",
                });
            }


            const duplicateRoom =
                await Room.findOne({
                    roomNumber:
                        roomNumber.trim(),

                    _id: {
                        $ne: id,
                    },
                });


            if (duplicateRoom) {
                log(
                    "ERROR",
                    `Update Room failed: Room number already exists - ${roomNumber.trim()}`
                );

                return res.status(409).json({
                    message:
                        "Room number already exists",
                });
            }


            existingRoom.roomNumber =
                roomNumber.trim();
        }


        // ----------------------------------------------------
        // ROOM TYPE VALIDATION
        // ----------------------------------------------------

        if (
            roomType !== undefined
        ) {

            const allowedRoomTypes = [
                "AC",
                "Non-AC",
            ];


            if (
                !allowedRoomTypes.includes(
                    roomType
                )
            ) {
                log(
                    "ERROR",
                    `Update Room failed: Invalid room type - ${roomType}`
                );

                return res.status(400).json({
                    message:
                        "Room type must be AC or Non-AC",
                });
            }


            existingRoom.roomType =
                roomType;
        }


        // ----------------------------------------------------
        // BED TYPE VALIDATION
        // ----------------------------------------------------

        if (
            bedType !== undefined
        ) {

            const allowedBedTypes = [
                "Single Bed",
                "2 Bed",
                "3 Bed",
            ];


            if (
                !allowedBedTypes.includes(
                    bedType
                )
            ) {
                log(
                    "ERROR",
                    `Update Room failed: Invalid bed type - ${bedType}`
                );

                return res.status(400).json({
                    message:
                        "Bed type must be Single Bed, 2 Bed or 3 Bed",
                });
            }


            existingRoom.bedType =
                bedType;
        }


        // ----------------------------------------------------
        // PRICE VALIDATION
        // ----------------------------------------------------

        if (
            pricePerNight !==
            undefined
        ) {

            if (
                pricePerNight === "" ||
                pricePerNight === null
            ) {
                log(
                    "ERROR",
                    `Update Room failed: Price is empty - ${id}`
                );

                return res.status(400).json({
                    message:
                        "Price per night is required",
                });
            }


            const price =
                Number(
                    pricePerNight
                );


            if (
                !Number.isFinite(
                    price
                ) ||
                price <= 0
            ) {
                log(
                    "ERROR",
                    `Update Room failed: Invalid price - ${pricePerNight}`
                );

                return res.status(400).json({
                    message:
                        "Price per night must be a valid number greater than 0",
                });
            }


            existingRoom.pricePerNight =
                price;
        }


        // ----------------------------------------------------
        // STATUS VALIDATION
        // ----------------------------------------------------

        if (
            status !== undefined
        ) {

            const allowedStatuses = [
                "available",
                "occupied",
            ];


            if (
                !allowedStatuses.includes(
                    status
                )
            ) {
                log(
                    "ERROR",
                    `Update Room failed: Invalid status - ${status}`
                );

                return res.status(400).json({
                    message:
                        "Room status must be available or occupied",
                });
            }


            existingRoom.status =
                status;
        }


        // ----------------------------------------------------
        // SAVE UPDATED ROOM
        // ----------------------------------------------------

        const updatedRoom =
            await existingRoom.save();


        log(
            "INFO",
            `Room updated successfully: ${updatedRoom.roomNumber}`
        );


        return res.status(200).json({
            message:
                "Room updated successfully",

            room:
                updatedRoom,
        });


    } catch (error) {

        log(
            "ERROR",
            `Update Room error: ${error.message}`
        );


        console.error(
            "Update Room error:",
            error
        );


        return res.status(500).json({
            message:
                "Failed to update room",
        });
    }
};



// ============================================================
// DELETE ROOM
// ============================================================

const deleteRoom = async (req, res) => {
    try {

        const {
            id,
        } = req.params;


        // ----------------------------------------------------
        // OBJECT ID VALIDATION
        // ----------------------------------------------------

        if (
            !mongoose.Types.ObjectId.isValid(
                id
            )
        ) {
            log(
                "ERROR",
                `Delete Room failed: Invalid room ID - ${id}`
            );

            return res.status(400).json({
                message:
                    "Invalid room ID",
            });
        }


        // ----------------------------------------------------
        // FIND ROOM
        // ----------------------------------------------------

        const room =
            await Room.findById(id);


        if (!room) {
            log(
                "ERROR",
                `Delete Room failed: Room not found - ${id}`
            );

            return res.status(404).json({
                message:
                    "Room not found",
            });
        }


        // ----------------------------------------------------
        // DO NOT DELETE OCCUPIED ROOM
        // ----------------------------------------------------

        if (
            room.status ===
            "occupied"
        ) {
            log(
                "ERROR",
                `Delete Room failed: Room ${room.roomNumber} is currently occupied`
            );

            return res.status(400).json({
                message:
                    "Occupied room cannot be deleted",
            });
        }


        // ----------------------------------------------------
        // DELETE ROOM
        // ----------------------------------------------------

        await Room.findByIdAndDelete(
            id
        );


        log(
            "INFO",
            `Room deleted successfully: ${room.roomNumber}`
        );


        return res.status(200).json({
            message:
                "Room deleted successfully",
        });


    } catch (error) {

        log(
            "ERROR",
            `Delete Room error: ${error.message}`
        );


        console.error(
            "Delete Room error:",
            error
        );


        return res.status(500).json({
            message:
                "Failed to delete room",
        });
    }
};



// ============================================================
// EXPORT
// ============================================================

export {
    addRoom,
    getAllRooms,
    getRoom,
    updateRoom,
    deleteRoom,
};