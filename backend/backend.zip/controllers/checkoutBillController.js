import CheckoutBill from "../models/checkoutBill.js";
import { log } from "../util/logger.js";

// 1. Create a new Checkout Bill
export const createCheckoutBill = async (req, res) => {
  try {
    log("Request received to create a new checkout bill.");
    
    const {
      customer,
      extraCharges,
      roomExtraStay,
      gst,
      initialPaidAmount,
      grandTotal,
      stayStatus,
      checkoutDateTime
    } = req.body;

    // Validate required fields
    if (!customer || grandTotal === undefined) {
      return res.status(400).json({
        success: false,
        message: "Customer reference and grand total are required to create a bill."
      });
    }

    const newBill = new CheckoutBill({
      customer,
      extraCharges,
      roomExtraStay,
      gst,
      initialPaidAmount,
      grandTotal,
      stayStatus,
      checkoutDateTime
    });

    const savedBill = await newBill.save();
    
    // Populate customer details before sending response
    const populatedBill = await CheckoutBill.findById(savedBill._id).populate("customer");

    log(`Checkout bill successfully created for customer ID: ${customer}`);

    return res.status(201).json({
      success: true,
      message: "Checkout bill has been successfully created.",
      data: populatedBill
    });
  } catch (error) {
    log(`Error creating checkout bill: ${error.message}`);
    console.error("Create bill error:", error);

    return res.status(500).json({
      success: false,
      message: "An unexpected error occurred while creating the checkout bill. Please try again.",
      error: error.message
    });
  }
};

// 2. Get All Checkout Bills
export const getAllCheckoutBills = async (req, res) => {
  try {
    log("Request received to fetch all checkout bills.");

    const bills = await CheckoutBill.find()
      .populate("customer")
      .sort({ createdAt: -1 });

    log(`Successfully fetched ${bills.length} checkout bill(s).`);

    return res.status(200).json({
      success: true,
      count: bills.length,
      message: "Checkout bills retrieved successfully.",
      data: bills
    });
  } catch (error) {
    log(`Error fetching checkout bills: ${error.message}`);
    console.error("Get all bills error:", error);

    return res.status(500).json({
      success: false,
      message: "An internal server error occurred while retrieving checkout bills."
    });
  }
};

// 3. Get Checkout Bill By ID
export const getCheckoutBillById = async (req, res) => {
  try {
    const { id } = req.params;
    log(`Request received to fetch checkout bill with ID: ${id}`);

    const bill = await CheckoutBill.findById(id).populate("customer");

    if (!bill) {
      return res.status(404).json({
        success: false,
        message: "The requested checkout bill could not be found in our database."
      });
    }

    log(`Successfully retrieved checkout bill for ID: ${id}`);

    return res.status(200).json({
      success: true,
      message: "Checkout bill retrieved successfully.",
      data: bill
    });
  } catch (error) {
    log(`Error fetching checkout bill by ID (${req.params.id}): ${error.message}`);
    console.error("Get bill by ID error:", error);

    return res.status(500).json({
      success: false,
      message: "An internal server error occurred while loading the checkout bill details."
    });
  }
};

// 4. Update Checkout Bill
export const updateCheckoutBill = async (req, res) => {
  try {
    const { id } = req.params;
    log(`Request received to update checkout bill with ID: ${id}`);

    const updateData = req.body;

    const updatedBill = await CheckoutBill.findByIdAndUpdate(
      id,
      { $set: updateData },
      { new: true, runValidators: true }
    ).populate("customer");

    if (!updatedBill) {
      return res.status(404).json({
        success: false,
        message: "The checkout bill you are trying to update does not exist."
      });
    }

    log(`Checkout bill successfully updated for ID: ${id}`);

    return res.status(200).json({
      success: true,
      message: "Checkout bill has been updated successfully.",
      data: updatedBill
    });
  } catch (error) {
    log(`Error updating checkout bill (${req.params.id}): ${error.message}`);
    console.error("Update bill error:", error);

    return res.status(500).json({
      success: false,
      message: "An unexpected error occurred while updating the checkout bill.",
      error: error.message
    });
  }
};

// 5. Delete Checkout Bill
export const deleteCheckoutBill = async (req, res) => {
  try {
    const { id } = req.params;
    log(`Request received to delete checkout bill with ID: ${id}`);

    const deletedBill = await CheckoutBill.findByIdAndDelete(id);

    if (!deletedBill) {
      return res.status(404).json({
        success: false,
        message: "The checkout bill you are trying to delete could not be found."
      });
    }

    log(`Checkout bill successfully deleted for ID: ${id}`);

    return res.status(200).json({
      success: true,
      message: "Checkout bill has been deleted successfully."
    });
  } catch (error) {
    log(`Error deleting checkout bill (${req.params.id}): ${error.message}`);
    console.error("Delete bill error:", error);

    return res.status(500).json({
      success: false,
      message: "An internal server error occurred while deleting the checkout bill."
    });
  }
};