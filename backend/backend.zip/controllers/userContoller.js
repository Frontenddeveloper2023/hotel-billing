import User from "../models/users.js"; 
import { log } from "../util/logger.js";


export const createUser = async (req, res) => {
    try {
        const { name, email, role, status, permission } = req.body;

        // 1. Human-readable validation checks
        if (!name || !name.trim()) {
            return res.status(400).json({ success: false, message: "Please provide a valid full name for the user." });
        }

        if (!email || !email.trim()) {
            return res.status(400).json({ success: false, message: "An email address is required to create a user account." });
        }

        const emailRegex = /\S+@\S+\.\S+/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({ success: false, message: "The email address format entered is invalid. Please check and try again." });
        }

        if (!role || !["admin", "receptionist"].includes(role.toLowerCase())) {
            return res.status(400).json({ success: false, message: "Please select a valid user role: either Admin or Receptionist." });
        }

        // 2. Check if user already exists
        const existingUser = await User.findOne({ email: email.toLowerCase().trim() });
        if (existingUser) {
            return res.status(409).json({ success: false, message: "An account with this email address already exists in the system." });
        }

        // 3. Create user (accepting raw frontend permission object dynamically for future scalability)
        const newUser = new User({
            name: name.trim(),
            email: email.toLowerCase().trim(),
            role: role.toLowerCase(),
            status: status || "active",
            permission: permission || {} 
        });

        const savedUser = await newUser.save();

        return res.status(201).json({
            success: true,
            message: "User account has been successfully created.",
            data: savedUser
        });

    } catch (error) {
        log.error(`[createUser Error]: Failed to create user. Details: ${error.message}`, { stack: error.stack });
        return res.status(500).json({
            success: false,
            message: "An unexpected error occurred on the server while trying to create the user. Please try again later."
        });
    }
};

/**
 * Retrieve all users in the system.
 */
export const getAllUsers = async (req, res) => {
    try {
        const users = await User.find({}).sort({ createdAt: -1 });

        return res.status(200).json({
            success: true,
            count: users.length,
            users
        });
    } catch (error) {
        log.error(`[getAllUsers Error]: Failed to fetch users list. Details: ${error.message}`, { stack: error.stack });
        return res.status(500).json({
            success: false,
            message: "Unable to load the users list right now. Please try again later."
        });
    }
};

/**
 * Update an existing user and accept dynamic permissions from the frontend.
 */
export const updateUser = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, email, role, status, permission } = req.body;

        if (!id) {
            return res.status(400).json({ success: false, message: "User identifier is missing from the request." });
        }

        // 1. Human-readable validation checks
        if (name !== undefined && !name.trim()) {
            return res.status(400).json({ success: false, message: "User name cannot be left empty." });
        }

        if (email !== undefined) {
            const emailRegex = /\S+@\S+\.\S+/;
            if (!email.trim() || !emailRegex.test(email)) {
                return res.status(400).json({ success: false, message: "Please provide a valid email address format." });
            }
        }

        if (role !== undefined && !["admin", "receptionist"].includes(role.toLowerCase())) {
            return res.status(400).json({ success: false, message: "Invalid role assigned. Allowed roles are Admin or Receptionist." });
        }

        // Find user first to make sure they exist
        const userToUpdate = await User.findById(id);
        if (!userToUpdate) {
            return res.status(404).json({ success: false, message: "The user you are trying to update could not be found." });
        }

        // Check email uniqueness if email is changing
        if (email && email.toLowerCase().trim() !== userToUpdate.email) {
            const emailExists = await User.findOne({ email: email.toLowerCase().trim() });
            if (emailExists) {
                return res.status(409).json({ success: false, message: "This email address is already associated with another account." });
            }
        }

        // Build update payload dynamically
        const updateData = {};
        if (name !== undefined) updateData.name = name.trim();
        if (email !== undefined) updateData.email = email.toLowerCase().trim();
        if (role !== undefined) updateData.role = role.toLowerCase();
        if (status !== undefined) updateData.status = status;
        
        // Dynamically assign permissions object straight from frontend to support future sidebars easily
        if (permission !== undefined) {
            updateData.permission = permission;
        }

        const updatedUser = await User.findByIdAndUpdate(id, updateData, { new: true, runValidators: true });

        return res.status(200).json({
            success: true,
            message: "User details have been successfully updated.",
            data: updatedUser
        });

    } catch (error) {
        log.error(`[updateUser Error]: Failed to update user ID ${req.params?.id}. Details: ${error.message}`, { stack: error.stack });
        return res.status(500).json({
            success: false,
            message: "An internal server error occurred while updating the user profile. Please try again."
        });
    }
};

/**
 * Delete a user by ID.
 */
export const deleteUser = async (req, res) => {
    try {
        const { id } = req.params;

        if (!id) {
            return res.status(400).json({ success: false, message: "User ID is required for deletion." });
        }

        const userToDelete = await User.findById(id);
        if (!userToDelete) {
            return res.status(404).json({ success: false, message: "The user you are trying to delete does not exist." });
        }

        // Prevent deleting main admin safeguard rule if needed
        if (userToDelete.role === "admin" && userToDelete.email === "admin@ssresidency.com") { // Adjust safeguard condition as per your project schema
            // Optional safeguard log/check
        }

        await User.findByIdAndDelete(id);

        return res.status(200).json({
            success: true,
            message: "User has been successfully deleted from the system."
        });

    } catch (error) {
        log.error(`[deleteUser Error]: Failed to delete user ID ${req.params?.id}. Details: ${error.message}`, { stack: error.stack });
        return res.status(500).json({
            success: false,
            message: "Server error occurred while attempting to delete the user. Please try again later."
        });
    }
};