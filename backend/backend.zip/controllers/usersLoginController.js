import User from "../models/users.js";

import { sendOTP } from "../util/email.js";

import jwt from "jsonwebtoken";

import { log } from "../util/logger.js";

const sendOTPForLogin = async (req, res) => {
    try {
        const { email } = req.body;

        console.log('Login request received for email:', email);

        if (!email) {
            return res.status(400).json({ message: 'Email is required' });
        }
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        
        if (user.is_active === false) {
            return res.status(401).json({ message: 'User is inactive' });
        }

        // Generate 6-digit OTP
        const otp = Math.floor(100000 + Math.random() * 900000).toString();

        // OTP expiry: 5 minutes
        const otpExpiresAt = new Date(Date.now() + 5 * 60 * 1000);

        // Save OTP
        user.otp = otp;
        user.otpExpiresAt = otpExpiresAt;

        await user.save();

        // Send OTP via email
        await sendOTP(email, otp);

        return res.status(200).json({
            message: 'OTP sent successfully'
        });
    } catch (error) {
        res.status(500).json({ message: 'Internal server error', error: error.message });
    }
};

const verifyOTP = async (req, res) => {
    try {
        const { email, otp } = req.body;

        if (!email || !otp) {
            return res.status(400).json({
                message: 'Email and OTP are required'
            });
        }

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(404).json({
                message: 'User not found'
            });
        }

        if (String(user.otp) !== String(otp)) {
            return res.status(401).json({
                message: 'Invalid OTP'
            });
        }

        if (user.otpExpiresAt < new Date()) {
            return res.status(401).json({
                message: 'OTP has expired'
            });
        }

        if (!process.env.JWT_SECRET) {
            throw new Error(
                'JWT_SECRET is not defined in environment variables'
            );
        }

        // JWT token expires after 24 hours
        const token = jwt.sign(
            {
                id: user._id,
                name: user.name,
                role: user.role
            },
            process.env.JWT_SECRET,
            {
                expiresIn: '24h'
            }
        );

        // Set token in HTTP-only cookie
       res.cookie("hotelbilling", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
    maxAge: 24 * 60 * 60 * 1000,
    path: "/",
});

        // Clear OTP after successful verification
        user.otp = null;
        user.otpExpiresAt = null;
        await user.save();

        return res.status(200).json({
            message: 'OTP verified successfully',
            user
        });

    } catch (error) {
        console.error(error);

        return res.status(500).json({
            message: 'Internal server error'
        });
    }
};

const logout = async (req, res) => {
    try {
        res.clearCookie('hotelbilling');
        log(`User logged out: ${req.user.name}`);
        res.status(200).json({ message: 'Logout successful' });
    } catch (error) {
        res.status(500).json({ message: 'Internal server error'});
    }
};

const getUser = async (req, res) => {
    try {
        // req.user is populated by your authVerify middleware from the JWT token
        const user = await User.findById(req.user.id).select("-otp -otpExpiresAt");
        
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        return res.status(200).json({ user });
    } catch (error) {
        console.error("Get user error:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
};





export {
    sendOTPForLogin,
    verifyOTP,
    logout,
    getUser
};