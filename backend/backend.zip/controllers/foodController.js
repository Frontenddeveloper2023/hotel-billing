import Food from "../models/food.js";
import { log } from "../util/logger.js";
import fs from "fs";
import path from "path";

// 1. CREATE FOOD ITEM
export const createFood = async (req, res) => {
    try {
        const { foodName, description, foodPrice, foodQuantity } = req.body;

        // Step 1: Validate required fields explicitly
        if (!foodName || !foodName.trim()) {
            return res.status(400).json({ success: false, message: "Food name is required." });
        }
        if (foodPrice === undefined || foodPrice === null || foodPrice === "") {
            return res.status(400).json({ success: false, message: "Food price is required." });
        }
        if (Number(foodPrice) < 0) {
            return res.status(400).json({ success: false, message: "Food price cannot be negative." });
        }
        if (foodQuantity === undefined || foodQuantity === null || foodQuantity === "") {
            return res.status(400).json({ success: false, message: "Food quantity is required." });
        }
        if (Number(foodQuantity) < 0) {
            return res.status(400).json({ success: false, message: "Food quantity cannot be negative." });
        }

        // Step 2: Handle food image upload via multer
        let imagePath = "";
        if (req.file) {
            imagePath = `uploads/foods/${req.file.filename}`;
        }

        // Step 3: Create food record in database
        const newFood = await Food.create({
            foodName: foodName.trim(),
            description: description ? description.trim() : "",
            foodPrice: Number(foodPrice),
            foodQuantity: Number(foodQuantity),
            foodImage: imagePath,
        });

        log.info(`Food item created successfully: ${newFood.foodName}`);

        return res.status(201).json({
            success: true,
            message: "Food item added successfully.",
            data: newFood,
        });

    } catch (error) {
        log.error(`Error creating food item: ${error.message}`);

        if (error.name === "ValidationError") {
            const messages = Object.values(error.errors).map(err => err.message);
            return res.status(400).json({
                success: false,
                message: `Validation failed: ${messages.join(", ")}`
            });
        }

        return res.status(500).json({
            success: false,
            message: "An internal server error occurred while creating the food item. Please try again later.",
        });
    }
};

// 2. GET ALL FOOD ITEMS
export const getAllFood = async (req, res) => {
    try {
        const foods = await Food.find().sort({ createdAt: -1 });

        return res.status(200).json({
            success: true,
            count: foods.length,
            data: foods,
        });
    } catch (error) {
        log.error(`Error fetching food list: ${error.message}`);
        return res.status(500).json({
            success: false,
            message: "Failed to fetch food items. Please try again later.",
        });
    }
};

// 3. GET SINGLE FOOD ITEM BY ID
export const getFoodById = async (req, res) => {
    try {
        const { id } = req.params;

        const food = await Food.findById(id);

        if (!food) {
            return res.status(404).json({
                success: false,
                message: "Food item not found with the provided ID.",
            });
        }

        return res.status(200).json({
            success: true,
            data: food,
        });
    } catch (error) {
        log.error(`Error fetching food by ID (${req.params.id}): ${error.message}`);

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message: "Invalid food ID format provided.",
            });
        }

        return res.status(500).json({
            success: false,
            message: "An internal server error occurred while retrieving the food item.",
        });
    }
};

// 4. UPDATE FOOD ITEM
// 4. UPDATE FOOD ITEM
export const updateFood = async (req, res) => {
    try {
        const { id } = req.params;

        // Step 1: Check if food item exists
        const existingFood = await Food.findById(id);
        if (!existingFood) {
            return res.status(404).json({
                success: false,
                message: "Food item not found for update.",
            });
        }

        const { foodName, description, foodPrice, foodQuantity, removeImage } = req.body;

        const updateData = {};
        if (foodName !== undefined) updateData.foodName = foodName.trim();
        if (description !== undefined) updateData.description = description.trim();
        if (foodPrice !== undefined) {
            if (Number(foodPrice) < 0) {
                return res.status(400).json({ success: false, message: "Food price cannot be negative." });
            }
            updateData.foodPrice = Number(foodPrice);
        }
        if (foodQuantity !== undefined) {
            if (Number(foodQuantity) < 0) {
                return res.status(400).json({ success: false, message: "Food quantity cannot be negative." });
            }
            updateData.foodQuantity = Number(foodQuantity);
        }

        // Step 2: Handle image file replacement or removal
        if (req.file) {
            // Match the plural "foods" directory used in your multer storage config
            const newImagePath = `uploads/foods/${req.file.filename}`;
            updateData.foodImage = newImagePath;

            // Delete old image file from disk if it exists
            if (existingFood.foodImage) {
                const oldFullPath = path.join(process.cwd(), existingFood.foodImage);
                if (fs.existsSync(oldFullPath)) {
                    fs.unlinkSync(oldFullPath);
                }
            }
        } else if (removeImage === 'true' || removeImage === true) {
            if (existingFood.foodImage) {
                const oldFullPath = path.join(process.cwd(), existingFood.foodImage);
                if (fs.existsSync(oldFullPath)) {
                    fs.unlinkSync(oldFullPath);
                }
            }
            updateData.foodImage = "";
        }

        // Step 3: Perform update in database
        const updatedFood = await Food.findByIdAndUpdate(
            id,
            { $set: updateData },
            { new: true, runValidators: true }
        );

        console.log(`Food item updated successfully: ${id}`);

        return res.status(200).json({
            success: true,
            message: "Food item updated successfully.",
            data: updatedFood,
        });

    } catch (error) {
        console.error(`Error updating food item (${req.params.id}): ${error.message}`);

        if (error.name === "ValidationError") {
            const messages = Object.values(error.errors).map(err => err.message);
            return res.status(400).json({
                success: false,
                message: `Validation failed: ${messages.join(", ")}`
            });
        }

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message: "Invalid food ID format provided.",
            });
        }

        return res.status(500).json({
            success: false,
            message: "An internal server error occurred while updating the food item.",
        });
    }
};

// 5. DELETE FOOD ITEM
export const deleteFood = async (req, res) => {
    try {
        const { id } = req.params;

        // Step 1: Check if food item exists
        const food = await Food.findById(id);
        if (!food) {
            return res.status(404).json({
                success: false,
                message: "Food item not found or already deleted.",
            });
        }

        // Step 2: Delete image file from disk if it exists
        if (food.foodImage) {
            const fullPath = path.join(process.cwd(), food.foodImage);
            if (fs.existsSync(fullPath)) {
                fs.unlinkSync(fullPath);
            }
        }

        // Step 3: Delete from database
        await Food.findByIdAndDelete(id);

        log.info(`Food item deleted successfully: ${id}`);

        return res.status(200).json({
            success: true,
            message: "Food item deleted successfully.",
        });

    } catch (error) {
        log.error(`Error deleting food item (${req.params.id}): ${error.message}`);

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message: "Invalid food ID format provided.",
            });
        }

        return res.status(500).json({
            success: false,
            message: "An internal server error occurred while deleting the food item.",
        });
    }
};