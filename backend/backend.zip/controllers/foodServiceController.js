import FoodService from "../models/foodService.js";
import Food from "../models/food.js";
import Customer from "../models/customers.js";
import { log } from "../util/logger.js";

// =====================================================
// 1. ADD FOOD ITEM TO CUSTOMER BILL
// =====================================================
export const createFoodService = async (req, res) => {
    try {
        const {
            customerId,
            roomNumber,
            foodId,
            quantity,
        } = req.body;

        // -------------------------------------------------
        // VALIDATE CUSTOMER
        // -------------------------------------------------
        if (!customerId || !String(customerId).trim()) {
            return res.status(400).json({
                success: false,
                message: "Customer ID is required.",
            });
        }

        // -------------------------------------------------
        // ⭐ VALIDATE ROOM NUMBER
        // -------------------------------------------------
        if (!roomNumber || !String(roomNumber).trim()) {
            return res.status(400).json({
                success: false,
                message: "Room number is required.",
            });
        }

        // -------------------------------------------------
        // VALIDATE FOOD
        // -------------------------------------------------
        if (!foodId || !String(foodId).trim()) {
            return res.status(400).json({
                success: false,
                message: "Food ID is required.",
            });
        }

        // -------------------------------------------------
        // VALIDATE QUANTITY
        // -------------------------------------------------
        if (
            quantity === undefined ||
            quantity === null ||
            quantity === ""
        ) {
            return res.status(400).json({
                success: false,
                message: "Food quantity is required.",
            });
        }

        if (Number(quantity) < 1) {
            return res.status(400).json({
                success: false,
                message: "Quantity must be at least 1.",
            });
        }

        // -------------------------------------------------
        // FIND CUSTOMER
        // -------------------------------------------------
        const customer = await Customer.findById(customerId);

        if (!customer) {
            return res.status(404).json({
                success: false,
                message: "Customer not found.",
            });
        }

        // -------------------------------------------------
        // ⭐ VERIFY ROOM BELONGS TO CUSTOMER
        // -------------------------------------------------
        const selectedRoom = customer.rooms?.find(
            (room) =>
                String(room.roomNumber).trim() ===
                String(roomNumber).trim()
        );

        if (!selectedRoom) {
            return res.status(404).json({
                success: false,
                message:
                    `Room ${roomNumber} is not booked by this customer.`,
            });
        }

        // -------------------------------------------------
        // FIND FOOD
        // -------------------------------------------------
        const foodItem = await Food.findById(foodId);

        if (!foodItem) {
            return res.status(404).json({
                success: false,
                message:
                    "Selected food item not found in the catalog.",
            });
        }

        // -------------------------------------------------
        // CALCULATE TOTAL
        // -------------------------------------------------
        const parsedQuantity = Number(quantity);

        const totalPrice =
            Number(foodItem.foodPrice) * parsedQuantity;

        // -------------------------------------------------
        // CREATE FOOD SERVICE
        // -------------------------------------------------
        const newFoodService = await FoodService.create({
            customerId: customer._id,

            // ⭐ SAVE ROOM NUMBER
            roomNumber: String(roomNumber).trim(),

            foodId: foodItem._id,

            foodName: foodItem.foodName,

            foodPrice: Number(foodItem.foodPrice),

            quantity: parsedQuantity,

            totalPrice,

            // New food always starts Pending
            paymentStatus: "Pending",
        });

        log.info(
            `Food service added successfully | Customer: ${customerId} | Room: ${roomNumber} | Food: ${foodItem.foodName} | Qty: ${parsedQuantity}`
        );

        return res.status(201).json({
            success: true,
            message:
                "Food item added to customer bill successfully.",
            data: newFoodService,
        });

    } catch (error) {
        log.error(
            `Error adding food service: ${error.message}`
        );

        if (error.name === "ValidationError") {
            const messages = Object.values(
                error.errors
            ).map((err) => err.message);

            return res.status(400).json({
                success: false,
                message:
                    `Validation failed: ${messages.join(", ")}`,
            });
        }

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid customer ID, room number, or food ID.",
            });
        }

        return res.status(500).json({
            success: false,
            message:
                "An internal server error occurred while adding the food item to the bill.",
        });
    }
};


// =====================================================
// 2. GET FOOD SERVICES FOR CUSTOMER
//
// Optional:
// ?roomNumber=104
//
// If roomNumber is provided:
// → only that room's food
//
// If roomNumber is not provided:
// → all customer's food
// =====================================================
export const getFoodServicesByCustomer = async (
    req,
    res
) => {
    try {
        const { customerId } = req.params;

        const roomNumber =
            req.query.roomNumber;

        // -------------------------------------------------
        // VALIDATE CUSTOMER ID
        // -------------------------------------------------
        if (!customerId) {
            return res.status(400).json({
                success: false,
                message:
                    "Customer ID parameter is required.",
            });
        }

        // -------------------------------------------------
        // BUILD QUERY
        // -------------------------------------------------
        const query = {
            customerId,
        };

        // ⭐ ROOM-SPECIFIC FILTER
        if (
            roomNumber !== undefined &&
            String(roomNumber).trim()
        ) {
            query.roomNumber =
                String(roomNumber).trim();
        }

        // -------------------------------------------------
        // GET FOOD SERVICES
        // -------------------------------------------------
        const foodServices =
            await FoodService.find(query)
                .sort({ createdAt: -1 });

        return res.status(200).json({
            success: true,
            count: foodServices.length,
            data: foodServices,
        });

    } catch (error) {
        log.error(
            `Error fetching food services for customer (${req.params.customerId}): ${error.message}`
        );

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid customer ID format provided.",
            });
        }

        return res.status(500).json({
            success: false,
            message:
                "Failed to fetch customer food services.",
        });
    }
};


// =====================================================
// 3. UPDATE FOOD SERVICE
//
// Used for:
// Pending → Paid
// Quantity update
// =====================================================
export const updateFoodService = async (
    req,
    res
) => {
    try {
        const { id } = req.params;

        // -------------------------------------------------
        // FIND EXISTING RECORD
        // -------------------------------------------------
        const existingRecord =
            await FoodService.findById(id);

        if (!existingRecord) {
            return res.status(404).json({
                success: false,
                message:
                    "Food service record not found for update.",
            });
        }

        const {
            paymentStatus,
            quantity,
            roomNumber,
        } = req.body;

        const updateData = {};

        // -------------------------------------------------
        // PAYMENT STATUS
        // -------------------------------------------------
        if (paymentStatus !== undefined) {
            if (
                !["Pending", "Paid"].includes(
                    paymentStatus
                )
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Invalid payment status. Allowed values are 'Pending' or 'Paid'.",
                });
            }

            updateData.paymentStatus =
                paymentStatus;
        }

        // -------------------------------------------------
        // QUANTITY
        // -------------------------------------------------
        if (quantity !== undefined) {
            const parsedQty =
                Number(quantity);

            if (
                !Number.isFinite(parsedQty) ||
                parsedQty < 1
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Quantity must be at least 1.",
                });
            }

            updateData.quantity =
                parsedQty;

            updateData.totalPrice =
                Number(existingRecord.foodPrice) *
                parsedQty;
        }

        // -------------------------------------------------
        // OPTIONAL ROOM NUMBER UPDATE
        // -------------------------------------------------
        if (roomNumber !== undefined) {
            if (
                !String(roomNumber).trim()
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Room number cannot be empty.",
                });
            }

            updateData.roomNumber =
                String(roomNumber).trim();
        }

        // -------------------------------------------------
        // UPDATE DATABASE
        // -------------------------------------------------
        const updatedFoodService =
            await FoodService.findByIdAndUpdate(
                id,
                {
                    $set: updateData,
                },
                {
                    new: true,
                    runValidators: true,
                }
            );

        log.info(
            `Food service updated | ID: ${id} | Status: ${updatedFoodService.paymentStatus}`
        );

        return res.status(200).json({
            success: true,
            message:
                "Food service record updated successfully.",
            data: updatedFoodService,
        });

    } catch (error) {
        log.error(
            `Error updating food service record (${req.params.id}): ${error.message}`
        );

        if (error.name === "ValidationError") {
            const messages = Object.values(
                error.errors
            ).map((err) => err.message);

            return res.status(400).json({
                success: false,
                message:
                    `Validation failed: ${messages.join(", ")}`,
            });
        }

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid food service record ID.",
            });
        }

        return res.status(500).json({
            success: false,
            message:
                "An internal server error occurred while updating the food service record.",
        });
    }
};


// =====================================================
// 4. DELETE FOOD SERVICE
// =====================================================
export const deleteFoodService = async (
    req,
    res
) => {
    try {
        const { id } = req.params;

        const record =
            await FoodService.findById(id);

        if (!record) {
            return res.status(404).json({
                success: false,
                message:
                    "Food service record not found or already deleted.",
            });
        }

        await FoodService.findByIdAndDelete(id);

        log.info(
            `Food service deleted | ID: ${id}`
        );

        return res.status(200).json({
            success: true,
            message:
                "Food item removed from bill successfully.",
        });

    } catch (error) {
        log.error(
            `Error deleting food service record (${req.params.id}): ${error.message}`
        );

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid food service record ID.",
            });
        }

        return res.status(500).json({
            success: false,
            message:
                "An internal server error occurred while deleting the food service record.",
        });
    }
};