import Invoice from "../models/invoice.js";
import InvoiceCounter from "../models/InvoiceCounter.js";
import { log } from "../util/logger.js";

// ============================================================
// HELPER - GENERATE ORDERLY INVOICE NUMBER
// ============================================================
const generateInvoiceNumber = async () => {
    const year = new Date().getFullYear();

    const counter = await InvoiceCounter.findOneAndUpdate(
        { year },
        {
            $inc: {
                sequence: 1,
            },
        },
        {
            new: true,
            upsert: true,
            setDefaultsOnInsert: true,
        }
    );

    const invoiceNo = `INV-${year}-${String(counter.sequence).padStart(6, "0")}`;

    return {
        invoiceNo,
        invoiceYear: year,
        invoiceSequence: counter.sequence,
    };
};

// ============================================================
// HELPER - FORMAT INVOICE DATE
// ============================================================
const formatInvoiceDate = (date = new Date()) => {
    return new Intl.DateTimeFormat("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
    }).format(date);
};

// ============================================================
// 1. CREATE INVOICE
// ============================================================
export const createInvoice = async (req, res) => {
    try {
        const {
            customer,
            room,
            rooms, // Multi-room array support
            staySummary,
            items,
            foodServicesDetails,
            roomServicesDetails,
            extraCharges,
            financials,
            billingDetails,
            paymentInfo,
        } = req.body;

        // ========================================================
        // VALIDATION
        // ========================================================
        if (!customer || !customer.customerName || !String(customer.customerName).trim()) {
            return res.status(400).json({
                success: false,
                message: "Customer name is required.",
            });
        }

        if (!customer.phoneNumber || !String(customer.phoneNumber).trim()) {
            return res.status(400).json({
                success: false,
                message: "Customer phone number is required.",
            });
        }

        // Handle rooms array or fallback to single room object / customer room fields
        let processedRooms = rooms;
        if ((!processedRooms || !Array.isArray(processedRooms) || processedRooms.length === 0)) {
            if (room && (room.roomNumber || customer.roomNumber)) {
                processedRooms = [{
                    roomNumber: room.roomNumber || customer.roomNumber,
                    roomType: room.roomType || customer.roomType,
                    bedType: room.bedType || customer.bedType,
                    perNightRoomPrice: room.perNightRoomPrice ?? customer.perNightRoomPrice ?? 0,
                    adults: room.adults ?? customer.adults ?? 0,
                    children: room.children ?? customer.children ?? 0
                }];
            }
        }

        if (!processedRooms || !Array.isArray(processedRooms) || processedRooms.length === 0) {
            return res.status(400).json({
                success: false,
                message: "At least one room reference is required for the invoice.",
            });
        }

        if (!financials) {
            return res.status(400).json({
                success: false,
                message: "Financial details are required.",
            });
        }

        if (financials.grandTotal === undefined || financials.grandTotal === null) {
            return res.status(400).json({
                success: false,
                message: "Financial grand total is required.",
            });
        }

        if (!paymentInfo) {
            return res.status(400).json({
                success: false,
                message: "Payment information is required.",
            });
        }

        // ========================================================
        // GENERATE SERVER-SIDE INVOICE NUMBER
        // ========================================================
        const {
            invoiceNo,
            invoiceYear,
            invoiceSequence,
        } = await generateInvoiceNumber();

        // Format rooms list for snapshot storage
        const formattedRooms = processedRooms.map(r => ({
            roomNumber: String(r.roomNumber || "").trim(),
            roomType: String(r.roomType || "").trim(),
            bedType: String(r.bedType || "").trim(),
            perNightRoomPrice: Number(r.perNightRoomPrice || 0),
            adults: Number(r.adults || 0),
            children: Number(r.children || 0),
        }));

        // ========================================================
        // CREATE INVOICE
        // ========================================================
        const newInvoice = await Invoice.create({
            invoiceNo,
            invoiceYear,
            invoiceSequence,
            invoiceDate:
                req.body.invoiceDate &&
                String(req.body.invoiceDate).trim()
                    ? String(req.body.invoiceDate).trim()
                    : formatInvoiceDate(),

            customerId: customer.customerId || null,

            customer: {
                customerId: customer.customerId || null,
                customerName: String(customer.customerName).trim(),
                phoneNumber: String(customer.phoneNumber || "").trim(),
                alternativePhone: String(
                    customer.alternativePhone ||
                    customer.altPhone ||
                    ""
                ).trim(),
                email: String(customer.email || "").trim(),
                address: String(customer.address || "").trim(),
                idProofType: String(
                    customer.idProofType ||
                    customer.idProof ||
                    ""
                ).trim(),
                idProofNumber: String(
                    customer.idProofNumber ||
                    ""
                ).trim(),
                rooms: formattedRooms, // Multi-room snapshot
                // Backward compatibility single-room attributes if needed by existing schemas
                roomNumber: formattedRooms[0]?.roomNumber || "",
                roomType: formattedRooms[0]?.roomType || "",
                bedType: formattedRooms[0]?.bedType || "",
                adults: formattedRooms[0]?.adults || 0,
                children: formattedRooms[0]?.children || 0,
            },

            // Room snapshot array & primary object fallback
            rooms: formattedRooms,
            room: formattedRooms[0] || {},

            staySummary: {
                bookedCheckIn: staySummary?.bookedCheckIn || "",
                bookedCheckInTime: staySummary?.bookedCheckInTime || "",
                bookedCheckOut: staySummary?.bookedCheckOut || "",
                bookedCheckOutTime: staySummary?.bookedCheckOutTime || "",
                actualCheckOut: staySummary?.actualCheckOut || "",
                actualCheckOutDate: staySummary?.actualCheckOutDate || "",
                actualCheckOutTime: staySummary?.actualCheckOutTime || "",
                bookedNights: Number(staySummary?.bookedNights) || 0,
                extraNights: Number(staySummary?.extraNights) || 0,
                extraHours: Number(staySummary?.extraHours) || 0,
                extraMinutes: Number(staySummary?.extraMinutes) || 0,
                extraTime: staySummary?.extraTime || "",
                totalExtraStayMinutes: Number(staySummary?.totalExtraStayMinutes) || 0,
                totalNightsStayed: Number(staySummary?.totalNightsStayed) || 0,
                overstayDescription: staySummary?.overstayDescription || "",
            },

            items: Array.isArray(items)
                ? items.map((item) => ({
                    description: String(item.description || "").trim(),
                    unitPrice: Number(item.unitPrice) || 0,
                    quantity: Number(item.quantity) || 0,
                    total: Number(item.total) || 0,
                }))
                : [],

            foodServicesDetails: Array.isArray(foodServicesDetails)
                ? foodServicesDetails.map((food) => ({
                    foodId: food.foodId || food._id || null,
                    name: String(food.name || food.foodName || "").trim(),
                    price: Number(food.price ?? food.foodPrice ?? 0),
                    quantity: Number(food.quantity ?? food.qty ?? 1),
                    total: Number(food.total ?? food.totalPrice ?? 0),
                }))
                : [],

            roomServicesDetails: Array.isArray(roomServicesDetails)
                ? roomServicesDetails.map((service) => ({
                    serviceId: service.serviceId || service._id || null,
                    name: String(service.name || service.serviceName || "").trim(),
                    fees: Number(
                        service.fees ??
                        service.serviceFees ??
                        service.fee ??
                        service.amount ??
                        0
                    ),
                    quantity: Number(service.quantity ?? 1),
                    total: Number(
                        service.total ??
                        service.serviceFees ??
                        service.fees ??
                        service.fee ??
                        service.amount ??
                        0
                    ),
                }))
                : [],

            extraCharges: {
                extraNightsStayed: Number(
                    extraCharges?.extraNightsStayed ??
                    staySummary?.extraNights ??
                    0
                ),
                extraNightRate: Number(
                    extraCharges?.extraNightRate ??
                    formattedRooms[0]?.perNightRoomPrice ??
                    0
                ),
                extraNightCharge: Number(extraCharges?.extraNightCharge) || 0,
                extraHoursStayed: Number(
                    extraCharges?.extraHoursStayed ??
                    staySummary?.extraHours ??
                    0
                ),
                extraMinutesStayed: Number(
                    extraCharges?.extraMinutesStayed ??
                    staySummary?.extraMinutes ??
                    0
                ),
                extraHoursCharge: Number(
                    extraCharges?.extraHoursCharge ??
                    extraCharges?.extraTimeCharge ??
                    0
                ),
                extraTimeCharge: Number(extraCharges?.extraTimeCharge) || 0,
                extraTimeChargeType: extraCharges?.extraTimeChargeType || "No extra time charge",
                extraTimeRatePercentage: Number(extraCharges?.extraTimeRatePercentage) || 0,
                lateCheckoutCharge: Number(extraCharges?.lateCheckoutCharge) || 0,
                damageCharge: Number(extraCharges?.damageCharge) || 0,
                otherCharges: Number(extraCharges?.otherCharges) || 0,
                otherChargesDescription: String(extraCharges?.otherChargesDescription || "").trim(),
                total: Number(
                    extraCharges?.total ??
                    extraCharges?.totalExtraCharge ??
                    financials?.totalExtraStayCharges ??
                    0
                ),
            },

            financials: {
                roomRent: Number(financials.roomRent) || 0,
                roomRentPerNight: Number(
                    financials.roomRentPerNight ??
                    formattedRooms[0]?.perNightRoomPrice ??
                    0
                ),
                foodServices: Number(financials.foodServices) || 0,
                roomServices: Number(financials.roomServices) || 0,
                extraNightCharge: Number(financials.extraNightCharge) || 0,
                extraTimeCharge: Number(financials.extraTimeCharge) || 0,
                totalExtraStayCharges: Number(financials.totalExtraStayCharges) || 0,
                subTotal: Number(financials.subTotal ?? financials.subtotal ?? 0),
                gstPercentage: Number(financials.gstPercentage) || 15,
                gstAmount: Number(financials.gstAmount) || 0,
                grandTotal: Number(financials.grandTotal) || 0,
                advancePaid: Number(financials.advancePaid) || 0,
                advancePaidVia: String(financials.advancePaidVia || "cash"),
                currentPayment: Number(financials.currentPayment) || 0,
                totalPaid: Number(financials.totalPaid) || 0,
                balanceDue: Number(financials.balanceDue) || 0,
            },

            billingDetails: billingDetails && typeof billingDetails === "object" ? billingDetails : {},

            paymentInfo: {
                paymentMode: String(paymentInfo?.paymentMode || "Cash").trim(),
                paymentStatus: String(paymentInfo?.paymentStatus || "PAID").trim(),
                paidAt: paymentInfo?.paidAt || "",
                transactionId: String(paymentInfo?.transactionId || "").trim(),
            },

            status:
                paymentInfo?.paymentStatus === "PAID"
                    ? "PAID"
                    : financials?.balanceDue > 0
                        ? "PARTIAL"
                        : "ISSUED",
        });

        log.info(`Invoice created successfully: ${newInvoice.invoiceNo}`);

        return res.status(201).json({
            success: true,
            message: "Invoice stored successfully.",
            data: newInvoice,
        });

    } catch (error) {
        log.error(`Error creating invoice: ${error.message}`);

        if (error.name === "ValidationError") {
            const messages = Object.values(error.errors).map((err) => err.message);
            return res.status(400).json({
                success: false,
                message: `Validation failed: ${messages.join(", ")}`,
            });
        }

        if (error.code === 11000) {
            return res.status(409).json({
                success: false,
                message: "Invoice number already exists. Please try again.",
            });
        }

        return res.status(500).json({
            success: false,
            message: "An internal server error occurred while creating the invoice. Please try again later.",
        });
    }
};

// ============================================================
// 2. GET ALL INVOICES
// ============================================================
export const getAllInvoices = async (req, res) => {
    try {
        const invoices = await Invoice.find().sort({
            invoiceYear: -1,
            invoiceSequence: -1,
        });

        return res.status(200).json({
            success: true,
            count: invoices.length,
            data: invoices,
        });
    } catch (error) {
        log.error(`Error fetching invoice list: ${error.message}`);
        return res.status(500).json({
            success: false,
            message: "Failed to fetch invoices. Please try again later.",
        });
    }
};

// ============================================================
// 3. GET SINGLE INVOICE BY ID
// ============================================================
export const getInvoiceById = async (req, res) => {
    try {
        const { id } = req.params;
        const invoice = await Invoice.findById(id);

        if (!invoice) {
            return res.status(404).json({
                success: false,
                message: "Invoice not found with the provided ID.",
            });
        }

        return res.status(200).json({
            success: true,
            data: invoice,
        });
    } catch (error) {
        log.error(`Error fetching invoice by ID (${req.params.id}): ${error.message}`);

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message: "Invalid invoice ID format provided.",
            });
        }

        return res.status(500).json({
            success: false,
            message: "An internal server error occurred while retrieving the invoice.",
        });
    }
};

// ============================================================
// 4. DELETE INVOICE
// ============================================================
export const deleteInvoice = async (req, res) => {
    try {
        const { id } = req.params;

        const invoice = await Invoice.findById(id);
        if (!invoice) {
            return res.status(404).json({
                success: false,
                message: "Invoice not found or already deleted.",
            });
        }

        await Invoice.findByIdAndDelete(id);
        log.info(`Invoice deleted successfully: ${id}`);

        return res.status(200).json({
            success: true,
            message: "Invoice deleted successfully.",
        });
    } catch (error) {
        log.error(`Error deleting invoice (${req.params.id}): ${error.message}`);

        if (error.name === "CastError") {
            return res.status(400).json({
                success: false,
                message: "Invalid invoice ID format provided.",
            });
        }

        return res.status(500).json({
            success: false,
            message: "An internal server error occurred while deleting the invoice.",
        });
    }
};