import express from "express";
import { 
    createUser, 
    getAllUsers, 
    updateUser, 
    deleteUser 
} from "../controllers/userContoller.js"; 
import { authVerify } from "../middleware/userVerify.js"; // Optional: Add auth protection if needed

const router = express.Router();

router.get("/list-users", authVerify, getAllUsers);
router.post("/add-user", authVerify, createUser);
router.put("/update-user/:id", authVerify, updateUser);
router.delete("/delete-user/:id", authVerify, deleteUser);

export default router;