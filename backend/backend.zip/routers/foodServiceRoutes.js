import express from "express";
import {
    createFoodService,
    getFoodServicesByCustomer,
    updateFoodService,
    deleteFoodService,
  
} from "../controllers/foodServiceController.js"; 

const router = express.Router();

// POST: Add a food item to a customer's bill
router.post("/", createFoodService);

// GET: Fetch all food items/orders for a specific customer
router.get("/customer/:customerId", getFoodServicesByCustomer);



// PUT: Update a food order (e.g., change quantity or paymentStatus to "Paid")
router.put("/:id", updateFoodService);

// DELETE: Remove an unconfirmed/pending food item from the customer's queue
router.delete("/:id", deleteFoodService);

export default router;