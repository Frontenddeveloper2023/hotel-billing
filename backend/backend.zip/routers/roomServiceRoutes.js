import express from "express";
import {
  addService,
  getAllServices,
  getServicesByCustomer,
  updateService,
  deleteService,
} from "../controllers/roomServiceController.js";

const router = express.Router();

// Route to add a new extra service
router.post("/add-room-service", addService);

// Route to get all extra services across all customers
router.get("/get-all-room-service", getAllServices);

// Route to get all services for a specific customer by their customerId
router.get("/get-room-service-by-customer/:customerId", getServicesByCustomer);

// Route to update an existing service by its service ID
router.put("/update-room-service-by-customer/:id", updateService);

// Route to delete a service record by its service ID
router.delete("/delete-room-service-by-customer/:id", deleteService);

export default router;