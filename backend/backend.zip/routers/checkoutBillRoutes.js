import express from "express";
import {
  createCheckoutBill,
  getAllCheckoutBills,
  getCheckoutBillById,
  updateCheckoutBill,
  deleteCheckoutBill
} from "../controllers/checkoutBillController.js";

const router = express.Router();

router.post("/create", createCheckoutBill);

router.get("/all", getAllCheckoutBills);

router.get("/:id", getCheckoutBillById);

router.put("/update/:id", updateCheckoutBill);

router.delete("/delete/:id", deleteCheckoutBill);

export default router;