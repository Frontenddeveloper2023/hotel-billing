import express from "express";

import {
    addRoom,
    getAllRooms,
    getRoom,
    updateRoom,
    deleteRoom,
} from "../controllers/roomController.js";

import {
    adminVerify,
} from "../middleware/userVerify.js";


const router = express.Router();


// ============================================================
// ROOM ROUTES
// ============================================================

// Add new room
router.post(
    "/add",
    adminVerify,
    addRoom
);


// Get all rooms
router.get(
    "/all",
    adminVerify,
    getAllRooms
);


// Get single room
router.get(
    "/:id",
    adminVerify,
    getRoom
);


// Update room
router.put(
    "/:id",
    adminVerify,
    updateRoom
);


// Delete room
router.delete(
    "/:id",
    adminVerify,
    deleteRoom
);


export default router;