import express from "express";
import {
    createCustomer,
    getAllCustomers,
    getCustomerById,
    updateCustomer,
    deleteCustomer,
    getOverstayCustomers 
} from "../controllers/customersController.js";

import { adminVerify } from "../middleware/userVerify.js"; 

const router = express.Router();

router.post("/create-customer", adminVerify, createCustomer);
router.get("/get-customer", adminVerify, getAllCustomers);
router.get("/get-overstays", adminVerify, getOverstayCustomers); 
router.get("/get-customer/:id", adminVerify, getCustomerById);
router.put("/update-customer/:id", adminVerify, updateCustomer);
router.delete("/delete-customer/:id", adminVerify, deleteCustomer);

export default router;