import express from "express";
import {
    createFood,
    getAllFood,
    getFoodById,
    updateFood,
    deleteFood
} from "../controllers/foodController.js";
import { uploadFoodImage } from "../middleware/uploadMiddleware.js"; 
import { adminVerify } from "../middleware/userVerify.js"; 

const router = express.Router();

router.post("/food-img-upload", adminVerify, uploadFoodImage, createFood);

router.get("/get-foods", adminVerify, getAllFood);

router.get("/get-food/:id", adminVerify, getFoodById);

router.put("/update-food/:id", adminVerify, uploadFoodImage, updateFood);

router.delete("/delete-food/:id", adminVerify, deleteFood);

export default router;