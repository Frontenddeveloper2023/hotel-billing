import express from "express";
import { getSettings, updateSettings } from "../controllers/settingsController.js";
import { uploadLogo } from "../middleware/uploadMiddleware.js";
import { adminVerify } from "../middleware/userVerify.js"; 

const router = express.Router();

router.get("/get-settings", adminVerify, getSettings);
router.put("/update-settings", adminVerify, uploadLogo, updateSettings);

export default router;