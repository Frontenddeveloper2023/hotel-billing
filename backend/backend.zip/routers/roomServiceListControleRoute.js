import express from "express";
import {
    createService,
    getAllServices,
    getService,
    updateService,
    deleteService,
} from "../controllers/roomServiceListControleController.js";

const router = express.Router();



router.post("/create-service", createService);
router.get("/get-all-services", getAllServices);
router.get("/get-service/:id", getService);
router.put("/update-service/:id", updateService);
router.delete("/delete-service/:id", deleteService);

export default router;